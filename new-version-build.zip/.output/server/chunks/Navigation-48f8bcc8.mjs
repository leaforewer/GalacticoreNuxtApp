import { _ as _imports_0, a as __nuxt_component_1 } from './galacticore-logo-6b391934.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-28d4e889.mjs';
import { defineComponent, reactive, ref, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode, resolveDynamicComponent, Transition, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderVNode } from 'vue/server-renderer';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel, PopoverGroup, Popover, PopoverButton, PopoverPanel } from '@headlessui/vue';
import { XMarkIcon, ChevronRightIcon } from '@heroicons/vue/24/outline';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import './server.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Navigation",
  __ssrInlineRender: true,
  props: {
    navigation: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const navigation = reactive(props.navigation);
    const isOpen = ref(false);
    const selectedNav = ref();
    const mobileSubNavisOpen = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GlobalShapeShiftG = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: isOpen.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-40 lg:hidden",
              onClose: ($event) => isOpen.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transition-opacity ease-linear duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-black bg-opacity-25"${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed inset-0 z-40 flex"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transition ease-in-out duration-300 transform",
                    "enter-from": "-translate-x-full",
                    "enter-to": "translate-x-0",
                    leave: "transition ease-in-out duration-300 transform",
                    "leave-from": "translate-x-0",
                    "leave-to": "-translate-x-full"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="flex px-4 pb-2 pt-5"${_scopeId4}><button type="button" class="-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400"${_scopeId4}><span class="sr-only"${_scopeId4}>Close menu</span>`);
                              _push5(ssrRenderComponent(unref(XMarkIcon), {
                                class: "h-6 w-6",
                                "aria-hidden": "true"
                              }, null, _parent5, _scopeId4));
                              _push5(`</button></div><div class="flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6"${_scopeId4}><div class="flex h-20 shrink-0 items-center"${_scopeId4}><img class="h-20 w-auto"${ssrRenderAttr("src", _imports_0)} alt=""${_scopeId4}></div><nav class="flex flex-1 flex-col"${_scopeId4}><ul role="list" class="flex flex-1 flex-col gap-y-7"${_scopeId4}><li${_scopeId4}><ul role="list" class="-mx-2 space-y-1"${_scopeId4}><!--[-->`);
                              ssrRenderList(unref(navigation), (navItem) => {
                                _push5(`<li${_scopeId4}>`);
                                if (navItem.href) {
                                  _push5(`<a${ssrRenderAttr("href", navItem.href)} class="${ssrRenderClass([
                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                    "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                  ])}"${_scopeId4}>${ssrInterpolate(navItem.name)}</a>`);
                                } else {
                                  _push5(`<div${_scopeId4}><button class="${ssrRenderClass([
                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                    "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                  ])}"${_scopeId4}>${ssrInterpolate(navItem.name)} `);
                                  _push5(ssrRenderComponent(unref(ChevronRightIcon), {
                                    class: [
                                      mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                      "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                    ],
                                    "aria-hidden": "true"
                                  }, null, _parent5, _scopeId4));
                                  _push5(`</button><ul class="${ssrRenderClass([
                                    mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                    "mt-1 px-2 transform transition-all ease-in-out"
                                  ])}"${_scopeId4}><!--[-->`);
                                  ssrRenderList(navItem.subNavigation, (subItem) => {
                                    _push5(`<li${_scopeId4}><a${ssrRenderAttr("href", subItem.href)} class="block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"${_scopeId4}>${ssrInterpolate(subItem.name)}</a></li>`);
                                  });
                                  _push5(`<!--]--></ul></div>`);
                                }
                                _push5(`</li>`);
                              });
                              _push5(`<!--]--></ul></li></ul></nav></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                    onClick: ($event) => isOpen.value = false
                                  }, [
                                    createVNode("span", { class: "sr-only" }, "Close menu"),
                                    createVNode(unref(XMarkIcon), {
                                      class: "h-6 w-6",
                                      "aria-hidden": "true"
                                    })
                                  ], 8, ["onClick"])
                                ]),
                                createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                  createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                    createVNode("img", {
                                      class: "h-20 w-auto",
                                      src: _imports_0,
                                      alt: ""
                                    })
                                  ]),
                                  createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                    createVNode("ul", {
                                      role: "list",
                                      class: "flex flex-1 flex-col gap-y-7"
                                    }, [
                                      createVNode("li", null, [
                                        createVNode("ul", {
                                          role: "list",
                                          class: "-mx-2 space-y-1"
                                        }, [
                                          (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                            return openBlock(), createBlock("li", {
                                              key: navItem.name
                                            }, [
                                              navItem.href ? (openBlock(), createBlock("a", {
                                                key: 0,
                                                onClick: ($event) => selectedNav.value = navItem.name,
                                                href: navItem.href,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                                createVNode("button", {
                                                  onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                  class: [
                                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                    "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                  ]
                                                }, [
                                                  createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                  createVNode(unref(ChevronRightIcon), {
                                                    class: [
                                                      mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                      "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                    ],
                                                    "aria-hidden": "true"
                                                  }, null, 8, ["class"])
                                                ], 10, ["onClick"]),
                                                createVNode("ul", {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                    "mt-1 px-2 transform transition-all ease-in-out"
                                                  ]
                                                }, [
                                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                    return openBlock(), createBlock("li", {
                                                      key: subItem.name
                                                    }, [
                                                      createVNode("a", {
                                                        href: subItem.href,
                                                        class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                      }, toDisplayString(subItem.name), 9, ["href"])
                                                    ]);
                                                  }), 128))
                                                ], 2)
                                              ]))
                                            ]);
                                          }), 128))
                                        ])
                                      ])
                                    ])
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                  onClick: ($event) => isOpen.value = false
                                }, [
                                  createVNode("span", { class: "sr-only" }, "Close menu"),
                                  createVNode(unref(XMarkIcon), {
                                    class: "h-6 w-6",
                                    "aria-hidden": "true"
                                  })
                                ], 8, ["onClick"])
                              ]),
                              createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                  createVNode("img", {
                                    class: "h-20 w-auto",
                                    src: _imports_0,
                                    alt: ""
                                  })
                                ]),
                                createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                  createVNode("ul", {
                                    role: "list",
                                    class: "flex flex-1 flex-col gap-y-7"
                                  }, [
                                    createVNode("li", null, [
                                      createVNode("ul", {
                                        role: "list",
                                        class: "-mx-2 space-y-1"
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                          return openBlock(), createBlock("li", {
                                            key: navItem.name
                                          }, [
                                            navItem.href ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => selectedNav.value = navItem.name,
                                              href: navItem.href,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                              createVNode("button", {
                                                onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, [
                                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                createVNode(unref(ChevronRightIcon), {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                    "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                  ],
                                                  "aria-hidden": "true"
                                                }, null, 8, ["class"])
                                              ], 10, ["onClick"]),
                                              createVNode("ul", {
                                                class: [
                                                  mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                  "mt-1 px-2 transform transition-all ease-in-out"
                                                ]
                                              }, [
                                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                  return openBlock(), createBlock("li", {
                                                    key: subItem.name
                                                  }, [
                                                    createVNode("a", {
                                                      href: subItem.href,
                                                      class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                    }, toDisplayString(subItem.name), 9, ["href"])
                                                  ]);
                                                }), 128))
                                              ], 2)
                                            ]))
                                          ]);
                                        }), 128))
                                      ])
                                    ])
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "transition-opacity ease-linear duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "transition-opacity ease-linear duration-300",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed inset-0 z-40 flex" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "transition ease-in-out duration-300 transform",
                        "enter-from": "-translate-x-full",
                        "enter-to": "translate-x-0",
                        leave: "transition ease-in-out duration-300 transform",
                        "leave-from": "translate-x-0",
                        "leave-to": "-translate-x-full"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                  onClick: ($event) => isOpen.value = false
                                }, [
                                  createVNode("span", { class: "sr-only" }, "Close menu"),
                                  createVNode(unref(XMarkIcon), {
                                    class: "h-6 w-6",
                                    "aria-hidden": "true"
                                  })
                                ], 8, ["onClick"])
                              ]),
                              createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                  createVNode("img", {
                                    class: "h-20 w-auto",
                                    src: _imports_0,
                                    alt: ""
                                  })
                                ]),
                                createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                  createVNode("ul", {
                                    role: "list",
                                    class: "flex flex-1 flex-col gap-y-7"
                                  }, [
                                    createVNode("li", null, [
                                      createVNode("ul", {
                                        role: "list",
                                        class: "-mx-2 space-y-1"
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                          return openBlock(), createBlock("li", {
                                            key: navItem.name
                                          }, [
                                            navItem.href ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => selectedNav.value = navItem.name,
                                              href: navItem.href,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                              createVNode("button", {
                                                onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, [
                                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                createVNode(unref(ChevronRightIcon), {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                    "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                  ],
                                                  "aria-hidden": "true"
                                                }, null, 8, ["class"])
                                              ], 10, ["onClick"]),
                                              createVNode("ul", {
                                                class: [
                                                  mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                  "mt-1 px-2 transform transition-all ease-in-out"
                                                ]
                                              }, [
                                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                  return openBlock(), createBlock("li", {
                                                    key: subItem.name
                                                  }, [
                                                    createVNode("a", {
                                                      href: subItem.href,
                                                      class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                    }, toDisplayString(subItem.name), 9, ["href"])
                                                  ]);
                                                }), 128))
                                              ], 2)
                                            ]))
                                          ]);
                                        }), 128))
                                      ])
                                    ])
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-40 lg:hidden",
                onClose: ($event) => isOpen.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "transition-opacity ease-linear duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed inset-0 z-40 flex" }, [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "transition ease-in-out duration-300 transform",
                      "enter-from": "-translate-x-full",
                      "enter-to": "translate-x-0",
                      leave: "transition ease-in-out duration-300 transform",
                      "leave-from": "translate-x-0",
                      "leave-to": "-translate-x-full"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                              createVNode("button", {
                                type: "button",
                                class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                onClick: ($event) => isOpen.value = false
                              }, [
                                createVNode("span", { class: "sr-only" }, "Close menu"),
                                createVNode(unref(XMarkIcon), {
                                  class: "h-6 w-6",
                                  "aria-hidden": "true"
                                })
                              ], 8, ["onClick"])
                            ]),
                            createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                              createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                createVNode("img", {
                                  class: "h-20 w-auto",
                                  src: _imports_0,
                                  alt: ""
                                })
                              ]),
                              createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                createVNode("ul", {
                                  role: "list",
                                  class: "flex flex-1 flex-col gap-y-7"
                                }, [
                                  createVNode("li", null, [
                                    createVNode("ul", {
                                      role: "list",
                                      class: "-mx-2 space-y-1"
                                    }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                        return openBlock(), createBlock("li", {
                                          key: navItem.name
                                        }, [
                                          navItem.href ? (openBlock(), createBlock("a", {
                                            key: 0,
                                            onClick: ($event) => selectedNav.value = navItem.name,
                                            href: navItem.href,
                                            class: [
                                              selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                              "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                            ]
                                          }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                            createVNode("button", {
                                              onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, [
                                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                              createVNode(unref(ChevronRightIcon), {
                                                class: [
                                                  mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                  "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                ],
                                                "aria-hidden": "true"
                                              }, null, 8, ["class"])
                                            ], 10, ["onClick"]),
                                            createVNode("ul", {
                                              class: [
                                                mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                "mt-1 px-2 transform transition-all ease-in-out"
                                              ]
                                            }, [
                                              (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                return openBlock(), createBlock("li", {
                                                  key: subItem.name
                                                }, [
                                                  createVNode("a", {
                                                    href: subItem.href,
                                                    class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                  }, toDisplayString(subItem.name), 9, ["href"])
                                                ]);
                                              }), 128))
                                            ], 2)
                                          ]))
                                        ]);
                                      }), 128))
                                    ])
                                  ])
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<header class="relative z-20"><nav aria-label="Top" class="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8"><div><div class="flex h-16 items-center"><button type="button" class="rounded-md p-2 text-gray-200 lg:hidden"><span class="sr-only">isOpen menu</span>`);
      _push(ssrRenderComponent(_component_GlobalShapeShiftG, null, null, _parent));
      _push(`</button><div class="ml-auto flex lg:ml-0"><a href="#"><span class="sr-only">Galacticore NFT</span><img class="h-20 w-auto"${ssrRenderAttr("src", _imports_0)} alt=""></a></div>`);
      if (unref(navigation).length) {
        _push(ssrRenderComponent(unref(PopoverGroup), { class: "hidden lg:ml-auto lg:block lg:self-stretch" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex h-full space-x-8"${_scopeId}><!--[-->`);
              ssrRenderList(unref(navigation), (navItem) => {
                _push2(ssrRenderComponent(unref(Popover), {
                  key: navItem.name,
                  class: "flex relative"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="relative flex"${_scopeId2}>`);
                      if (navItem.href) {
                        _push3(ssrRenderComponent(_component_NuxtLink, {
                          href: navItem.href,
                          onClick: ($event) => selectedNav.value = navItem.name,
                          class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                        }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`${ssrInterpolate(navItem.name)} <span class="${ssrRenderClass([selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"])}"${_scopeId3}></span>`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                createVNode("span", {
                                  class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                                }, null, 2)
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      } else {
                        _push3(ssrRenderComponent(unref(PopoverButton), {
                          class: [
                            isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                            "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                          ]
                        }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`${ssrInterpolate(navItem.name)} <span class="${ssrRenderClass([selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"])}"${_scopeId3}></span>`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                createVNode("span", {
                                  class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                                }, null, 2)
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      }
                      _push3(`</div>`);
                      _push3(ssrRenderComponent(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<div class="p-4"${_scopeId3}><!--[-->`);
                            ssrRenderList(navItem.subNavigation, (subItem) => {
                              _push4(`<div class="group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"${_scopeId3}><div class="flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white"${_scopeId3}>`);
                              ssrRenderVNode(_push4, createVNode(resolveDynamicComponent(subItem.icon), {
                                class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                "aria-hidden": "true"
                              }, null), _parent4, _scopeId3);
                              _push4(`</div><div class="flex-auto"${_scopeId3}><a${ssrRenderAttr("href", subItem.href)} class="block font-semibold text-base text-gray-200"${_scopeId3}>${ssrInterpolate(subItem.name)} <span class="absolute inset-0"${_scopeId3}></span></a><p class="mt-1 text-gray-400"${_scopeId3}>${ssrInterpolate(subItem.description)}</p></div></div>`);
                            });
                            _push4(`<!--]--></div>`);
                          } else {
                            return [
                              createVNode("div", { class: "p-4" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                  return openBlock(), createBlock("div", {
                                    key: subItem.name,
                                    class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                  }, [
                                    createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                      (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                        class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                        "aria-hidden": "true"
                                      }))
                                    ]),
                                    createVNode("div", { class: "flex-auto" }, [
                                      createVNode("a", {
                                        href: subItem.href,
                                        class: "block font-semibold text-base text-gray-200"
                                      }, [
                                        createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                        createVNode("span", { class: "absolute inset-0" })
                                      ], 8, ["href"]),
                                      createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                    ])
                                  ]);
                                }), 128))
                              ])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode("div", { class: "relative flex" }, [
                          navItem.href ? (openBlock(), createBlock(_component_NuxtLink, {
                            key: 0,
                            href: navItem.href,
                            onClick: ($event) => selectedNav.value = navItem.name,
                            class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["href", "onClick"])) : (openBlock(), createBlock(unref(PopoverButton), {
                            key: 1,
                            class: [
                              isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                              "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                            ]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["class"]))
                        ]),
                        createVNode(Transition, {
                          "enter-active-class": "transition ease-out duration-200",
                          "enter-from-class": "opacity-0 translate-y-1",
                          "enter-to-class": "opacity-100 translate-y-0",
                          "leave-active-class": "transition ease-in duration-150",
                          "leave-from-class": "opacity-100 translate-y-0",
                          "leave-to-class": "opacity-0 translate-y-1"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "p-4" }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                    return openBlock(), createBlock("div", {
                                      key: subItem.name,
                                      class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                    }, [
                                      createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                        (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                          class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                          "aria-hidden": "true"
                                        }))
                                      ]),
                                      createVNode("div", { class: "flex-auto" }, [
                                        createVNode("a", {
                                          href: subItem.href,
                                          class: "block font-semibold text-base text-gray-200"
                                        }, [
                                          createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                          createVNode("span", { class: "absolute inset-0" })
                                        ], 8, ["href"]),
                                        createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                      ])
                                    ]);
                                  }), 128))
                                ])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            } else {
              return [
                createVNode("div", { class: "flex h-full space-x-8" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                    return openBlock(), createBlock(unref(Popover), {
                      key: navItem.name,
                      class: "flex relative"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "relative flex" }, [
                          navItem.href ? (openBlock(), createBlock(_component_NuxtLink, {
                            key: 0,
                            href: navItem.href,
                            onClick: ($event) => selectedNav.value = navItem.name,
                            class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["href", "onClick"])) : (openBlock(), createBlock(unref(PopoverButton), {
                            key: 1,
                            class: [
                              isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                              "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                            ]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["class"]))
                        ]),
                        createVNode(Transition, {
                          "enter-active-class": "transition ease-out duration-200",
                          "enter-from-class": "opacity-0 translate-y-1",
                          "enter-to-class": "opacity-100 translate-y-0",
                          "leave-active-class": "transition ease-in duration-150",
                          "leave-from-class": "opacity-100 translate-y-0",
                          "leave-to-class": "opacity-0 translate-y-1"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "p-4" }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                    return openBlock(), createBlock("div", {
                                      key: subItem.name,
                                      class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                    }, [
                                      createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                        (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                          class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                          "aria-hidden": "true"
                                        }))
                                      ]),
                                      createVNode("div", { class: "flex-auto" }, [
                                        createVNode("a", {
                                          href: subItem.href,
                                          class: "block font-semibold text-base text-gray-200"
                                        }, [
                                          createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                          createVNode("span", { class: "absolute inset-0" })
                                        ], 8, ["href"]),
                                        createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                      ])
                                    ]);
                                  }), 128))
                                ])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></nav></header><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/global/Navigation.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Navigation-48f8bcc8.mjs.map
