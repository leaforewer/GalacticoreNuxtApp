import { b as buildAssetsURL } from './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'vue/server-renderer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const c20 = "" + buildAssetsURL("c20.50ca30f8.png");

export { c20 as default };
//# sourceMappingURL=c20-846d6ca2.mjs.map
