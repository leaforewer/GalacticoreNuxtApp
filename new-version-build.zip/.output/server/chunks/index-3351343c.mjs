import { _ as __nuxt_component_0 } from './layout-e31c9add.mjs';
import { _ as _imports_0, a as __nuxt_component_1 } from './galacticore-logo-6b391934.mjs';
import { useSSRContext, defineComponent, reactive, ref, withCtx, unref, createVNode, resolveDynamicComponent, createTextVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, mergeProps, Transition } from 'vue';
import { ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderVNode, ssrRenderAttrs, ssrRenderClass } from 'vue/server-renderer';
import { PuzzlePieceIcon, DocumentTextIcon, ChevronRightIcon, ChevronDownIcon, XMarkIcon } from '@heroicons/vue/24/outline';
import { _ as __nuxt_component_0$1 } from './nuxt-link-28d4e889.mjs';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel, PopoverGroup, Popover, PopoverButton, PopoverPanel } from '@headlessui/vue';
import { u as useHead } from './server.mjs';
import 'vue-router';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "AnimatedText",
  __ssrInlineRender: true,
  props: {
    text: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ "data-value": __props.text }, _attrs))}>${ssrInterpolate(__props.text)}</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Global/AnimatedText.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Faq",
  __ssrInlineRender: true,
  props: {
    items: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const selectedId = ref(0);
    const isOpened = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "flex flex-col justify-center items-center w-full" }, _attrs))}><!--[-->`);
      ssrRenderList(__props.items, (item, index) => {
        _push(`<li class="${ssrRenderClass([[
          index === 0 ? "rounded-t-md" : "",
          index > __props.items.length - 2 ? "rounded-b-md" : "",
          isOpened.value && item.id === selectedId.value ? "bg-sky-400 hover:text-white hover:font-normal" : "bg-[#121212]"
        ], "py-5 px-3 w-full border border-gray-500 cursor-pointer text-white hover:text-gray-400 hover:font-bold transition-all ease-in-out"])}"><div class="flex justify-between items-center"><span>${ssrInterpolate(item.question)}</span><div>`);
        _push(ssrRenderComponent(unref(ChevronDownIcon), {
          class: ["h-6 w-6 transition-all", isOpened.value && item.id === selectedId.value ? "rotate-180" : ""]
        }, null, _parent));
        _push(`</div></div><div class="${ssrRenderClass([
          isOpened.value && item.id === selectedId.value ? "max-h-[500px] p-5" : "max-h-0 p-0",
          "overflow-hidden font-semibold transition-all duration-500 ease-in-out text-white"
        ])}">${ssrInterpolate(item.answer)}</div></li>`);
      });
      _push(`<!--]--></ul>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Global/Faq.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Navigation",
  __ssrInlineRender: true,
  props: {
    navigation: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const navigation = reactive(props.navigation);
    const isOpen = ref(false);
    const selectedNav = ref();
    const mobileSubNavisOpen = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GlobalShapeShiftG = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: isOpen.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-40 lg:hidden",
              onClose: ($event) => isOpen.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transition-opacity ease-linear duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-black bg-opacity-25"${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed inset-0 z-40 flex"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transition ease-in-out duration-300 transform",
                    "enter-from": "-translate-x-full",
                    "enter-to": "translate-x-0",
                    leave: "transition ease-in-out duration-300 transform",
                    "leave-from": "translate-x-0",
                    "leave-to": "-translate-x-full"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="flex px-4 pb-2 pt-5"${_scopeId4}><button type="button" class="-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400"${_scopeId4}><span class="sr-only"${_scopeId4}>Close menu</span>`);
                              _push5(ssrRenderComponent(unref(XMarkIcon), {
                                class: "h-6 w-6",
                                "aria-hidden": "true"
                              }, null, _parent5, _scopeId4));
                              _push5(`</button></div><div class="flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6"${_scopeId4}><div class="flex h-20 shrink-0 items-center"${_scopeId4}><img class="h-20 w-auto"${ssrRenderAttr("src", _imports_0)} alt=""${_scopeId4}></div><nav class="flex flex-1 flex-col"${_scopeId4}><ul role="list" class="flex flex-1 flex-col gap-y-7"${_scopeId4}><li${_scopeId4}><ul role="list" class="-mx-2 space-y-1"${_scopeId4}><!--[-->`);
                              ssrRenderList(unref(navigation), (navItem) => {
                                _push5(`<li${_scopeId4}>`);
                                if (navItem.href) {
                                  _push5(`<a${ssrRenderAttr("href", navItem.href)} class="${ssrRenderClass([
                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                    "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                  ])}"${_scopeId4}>${ssrInterpolate(navItem.name)}</a>`);
                                } else {
                                  _push5(`<div${_scopeId4}><button class="${ssrRenderClass([
                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                    "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                  ])}"${_scopeId4}>${ssrInterpolate(navItem.name)} `);
                                  _push5(ssrRenderComponent(unref(ChevronRightIcon), {
                                    class: [
                                      mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                      "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                    ],
                                    "aria-hidden": "true"
                                  }, null, _parent5, _scopeId4));
                                  _push5(`</button><ul class="${ssrRenderClass([
                                    mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                    "mt-1 px-2 transform transition-all ease-in-out"
                                  ])}"${_scopeId4}><!--[-->`);
                                  ssrRenderList(navItem.subNavigation, (subItem) => {
                                    _push5(`<li${_scopeId4}><a${ssrRenderAttr("href", subItem.href)} class="block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"${_scopeId4}>${ssrInterpolate(subItem.name)}</a></li>`);
                                  });
                                  _push5(`<!--]--></ul></div>`);
                                }
                                _push5(`</li>`);
                              });
                              _push5(`<!--]--></ul></li></ul></nav></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                    onClick: ($event) => isOpen.value = false
                                  }, [
                                    createVNode("span", { class: "sr-only" }, "Close menu"),
                                    createVNode(unref(XMarkIcon), {
                                      class: "h-6 w-6",
                                      "aria-hidden": "true"
                                    })
                                  ], 8, ["onClick"])
                                ]),
                                createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                  createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                    createVNode("img", {
                                      class: "h-20 w-auto",
                                      src: _imports_0,
                                      alt: ""
                                    })
                                  ]),
                                  createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                    createVNode("ul", {
                                      role: "list",
                                      class: "flex flex-1 flex-col gap-y-7"
                                    }, [
                                      createVNode("li", null, [
                                        createVNode("ul", {
                                          role: "list",
                                          class: "-mx-2 space-y-1"
                                        }, [
                                          (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                            return openBlock(), createBlock("li", {
                                              key: navItem.name
                                            }, [
                                              navItem.href ? (openBlock(), createBlock("a", {
                                                key: 0,
                                                onClick: ($event) => selectedNav.value = navItem.name,
                                                href: navItem.href,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                                createVNode("button", {
                                                  onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                  class: [
                                                    selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                    "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                  ]
                                                }, [
                                                  createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                  createVNode(unref(ChevronRightIcon), {
                                                    class: [
                                                      mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                      "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                    ],
                                                    "aria-hidden": "true"
                                                  }, null, 8, ["class"])
                                                ], 10, ["onClick"]),
                                                createVNode("ul", {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                    "mt-1 px-2 transform transition-all ease-in-out"
                                                  ]
                                                }, [
                                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                    return openBlock(), createBlock("li", {
                                                      key: subItem.name
                                                    }, [
                                                      createVNode("a", {
                                                        href: subItem.href,
                                                        class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                      }, toDisplayString(subItem.name), 9, ["href"])
                                                    ]);
                                                  }), 128))
                                                ], 2)
                                              ]))
                                            ]);
                                          }), 128))
                                        ])
                                      ])
                                    ])
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                  onClick: ($event) => isOpen.value = false
                                }, [
                                  createVNode("span", { class: "sr-only" }, "Close menu"),
                                  createVNode(unref(XMarkIcon), {
                                    class: "h-6 w-6",
                                    "aria-hidden": "true"
                                  })
                                ], 8, ["onClick"])
                              ]),
                              createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                  createVNode("img", {
                                    class: "h-20 w-auto",
                                    src: _imports_0,
                                    alt: ""
                                  })
                                ]),
                                createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                  createVNode("ul", {
                                    role: "list",
                                    class: "flex flex-1 flex-col gap-y-7"
                                  }, [
                                    createVNode("li", null, [
                                      createVNode("ul", {
                                        role: "list",
                                        class: "-mx-2 space-y-1"
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                          return openBlock(), createBlock("li", {
                                            key: navItem.name
                                          }, [
                                            navItem.href ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => selectedNav.value = navItem.name,
                                              href: navItem.href,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                              createVNode("button", {
                                                onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, [
                                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                createVNode(unref(ChevronRightIcon), {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                    "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                  ],
                                                  "aria-hidden": "true"
                                                }, null, 8, ["class"])
                                              ], 10, ["onClick"]),
                                              createVNode("ul", {
                                                class: [
                                                  mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                  "mt-1 px-2 transform transition-all ease-in-out"
                                                ]
                                              }, [
                                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                  return openBlock(), createBlock("li", {
                                                    key: subItem.name
                                                  }, [
                                                    createVNode("a", {
                                                      href: subItem.href,
                                                      class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                    }, toDisplayString(subItem.name), 9, ["href"])
                                                  ]);
                                                }), 128))
                                              ], 2)
                                            ]))
                                          ]);
                                        }), 128))
                                      ])
                                    ])
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "transition-opacity ease-linear duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "transition-opacity ease-linear duration-300",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed inset-0 z-40 flex" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "transition ease-in-out duration-300 transform",
                        "enter-from": "-translate-x-full",
                        "enter-to": "translate-x-0",
                        leave: "transition ease-in-out duration-300 transform",
                        "leave-from": "translate-x-0",
                        "leave-to": "-translate-x-full"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                  onClick: ($event) => isOpen.value = false
                                }, [
                                  createVNode("span", { class: "sr-only" }, "Close menu"),
                                  createVNode(unref(XMarkIcon), {
                                    class: "h-6 w-6",
                                    "aria-hidden": "true"
                                  })
                                ], 8, ["onClick"])
                              ]),
                              createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                                createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                  createVNode("img", {
                                    class: "h-20 w-auto",
                                    src: _imports_0,
                                    alt: ""
                                  })
                                ]),
                                createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                  createVNode("ul", {
                                    role: "list",
                                    class: "flex flex-1 flex-col gap-y-7"
                                  }, [
                                    createVNode("li", null, [
                                      createVNode("ul", {
                                        role: "list",
                                        class: "-mx-2 space-y-1"
                                      }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                          return openBlock(), createBlock("li", {
                                            key: navItem.name
                                          }, [
                                            navItem.href ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => selectedNav.value = navItem.name,
                                              href: navItem.href,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                              createVNode("button", {
                                                onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                                class: [
                                                  selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                  "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                                ]
                                              }, [
                                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                                createVNode(unref(ChevronRightIcon), {
                                                  class: [
                                                    mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                    "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                  ],
                                                  "aria-hidden": "true"
                                                }, null, 8, ["class"])
                                              ], 10, ["onClick"]),
                                              createVNode("ul", {
                                                class: [
                                                  mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                  "mt-1 px-2 transform transition-all ease-in-out"
                                                ]
                                              }, [
                                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                  return openBlock(), createBlock("li", {
                                                    key: subItem.name
                                                  }, [
                                                    createVNode("a", {
                                                      href: subItem.href,
                                                      class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                    }, toDisplayString(subItem.name), 9, ["href"])
                                                  ]);
                                                }), 128))
                                              ], 2)
                                            ]))
                                          ]);
                                        }), 128))
                                      ])
                                    ])
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-40 lg:hidden",
                onClose: ($event) => isOpen.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "transition-opacity ease-linear duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-black bg-opacity-25" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed inset-0 z-40 flex" }, [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "transition ease-in-out duration-300 transform",
                      "enter-from": "-translate-x-full",
                      "enter-to": "translate-x-0",
                      leave: "transition ease-in-out duration-300 transform",
                      "leave-from": "translate-x-0",
                      "leave-to": "-translate-x-full"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogPanel), { class: "relative flex w-full max-w-sm flex-col overflow-y-auto bg-[#191919] pb-12 shadow-xl" }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "flex px-4 pb-2 pt-5" }, [
                              createVNode("button", {
                                type: "button",
                                class: "-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400",
                                onClick: ($event) => isOpen.value = false
                              }, [
                                createVNode("span", { class: "sr-only" }, "Close menu"),
                                createVNode(unref(XMarkIcon), {
                                  class: "h-6 w-6",
                                  "aria-hidden": "true"
                                })
                              ], 8, ["onClick"])
                            ]),
                            createVNode("div", { class: "flex grow flex-col gap-y-5 overflow-y-auto bg-[#191919] px-6" }, [
                              createVNode("div", { class: "flex h-20 shrink-0 items-center" }, [
                                createVNode("img", {
                                  class: "h-20 w-auto",
                                  src: _imports_0,
                                  alt: ""
                                })
                              ]),
                              createVNode("nav", { class: "flex flex-1 flex-col" }, [
                                createVNode("ul", {
                                  role: "list",
                                  class: "flex flex-1 flex-col gap-y-7"
                                }, [
                                  createVNode("li", null, [
                                    createVNode("ul", {
                                      role: "list",
                                      class: "-mx-2 space-y-1"
                                    }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                                        return openBlock(), createBlock("li", {
                                          key: navItem.name
                                        }, [
                                          navItem.href ? (openBlock(), createBlock("a", {
                                            key: 0,
                                            onClick: ($event) => selectedNav.value = navItem.name,
                                            href: navItem.href,
                                            class: [
                                              selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                              "block rounded-md py-4 pr-2 pl-6 text-base leading-6 font-semibold text-gray-200"
                                            ]
                                          }, toDisplayString(navItem.name), 11, ["onClick", "href"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                            createVNode("button", {
                                              onClick: ($event) => mobileSubNavisOpen.value = !mobileSubNavisOpen.value,
                                              class: [
                                                selectedNav.value === navItem.name ? "bg-[#222222]" : "hover:bg-[#222222]",
                                                "flex justify-between items-center w-full text-left rounded-md p-4 pl-6 gap-x-3 text-base leading-6 font-semibold text-gray-200"
                                              ]
                                            }, [
                                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                              createVNode(unref(ChevronRightIcon), {
                                                class: [
                                                  mobileSubNavisOpen.value ? "rotate-90 text-gray-500" : "text-gray-400",
                                                  "h-5 w-5 shrink-0 mr-5 transition-all ease-in-out"
                                                ],
                                                "aria-hidden": "true"
                                              }, null, 8, ["class"])
                                            ], 10, ["onClick"]),
                                            createVNode("ul", {
                                              class: [
                                                mobileSubNavisOpen.value ? "translate-x-0" : "translate-x-full",
                                                "mt-1 px-2 transform transition-all ease-in-out"
                                              ]
                                            }, [
                                              (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                                return openBlock(), createBlock("li", {
                                                  key: subItem.name
                                                }, [
                                                  createVNode("a", {
                                                    href: subItem.href,
                                                    class: "block rounded-md py-4 pr-2 pl-9 text-base leading-6 text-gray-200 hover:bg-[#222222]"
                                                  }, toDisplayString(subItem.name), 9, ["href"])
                                                ]);
                                              }), 128))
                                            ], 2)
                                          ]))
                                        ]);
                                      }), 128))
                                    ])
                                  ])
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<header class="relative z-20"><nav aria-label="Top" class="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8"><div><div class="flex h-16 items-center"><button type="button" class="rounded-md p-2 text-gray-200 lg:hidden"><span class="sr-only">isOpen menu</span>`);
      _push(ssrRenderComponent(_component_GlobalShapeShiftG, null, null, _parent));
      _push(`</button><div class="ml-auto flex lg:ml-0"><a href="#"><span class="sr-only">Galacticore NFT</span><img class="h-20 w-auto"${ssrRenderAttr("src", _imports_0)} alt=""></a></div>`);
      if (unref(navigation).length) {
        _push(ssrRenderComponent(unref(PopoverGroup), { class: "hidden lg:ml-auto lg:block lg:self-stretch" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex h-full space-x-8"${_scopeId}><!--[-->`);
              ssrRenderList(unref(navigation), (navItem) => {
                _push2(ssrRenderComponent(unref(Popover), {
                  key: navItem.name,
                  class: "flex relative"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="relative flex"${_scopeId2}>`);
                      if (navItem.href) {
                        _push3(ssrRenderComponent(_component_NuxtLink, {
                          href: navItem.href,
                          onClick: ($event) => selectedNav.value = navItem.name,
                          class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                        }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`${ssrInterpolate(navItem.name)} <span class="${ssrRenderClass([selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"])}"${_scopeId3}></span>`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                createVNode("span", {
                                  class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                                }, null, 2)
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      } else {
                        _push3(ssrRenderComponent(unref(PopoverButton), {
                          class: [
                            isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                            "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                          ]
                        }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`${ssrInterpolate(navItem.name)} <span class="${ssrRenderClass([selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"])}"${_scopeId3}></span>`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(navItem.name) + " ", 1),
                                createVNode("span", {
                                  class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                                }, null, 2)
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      }
                      _push3(`</div>`);
                      _push3(ssrRenderComponent(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<div class="p-4"${_scopeId3}><!--[-->`);
                            ssrRenderList(navItem.subNavigation, (subItem) => {
                              _push4(`<div class="group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"${_scopeId3}><div class="flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white"${_scopeId3}>`);
                              ssrRenderVNode(_push4, createVNode(resolveDynamicComponent(subItem.icon), {
                                class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                "aria-hidden": "true"
                              }, null), _parent4, _scopeId3);
                              _push4(`</div><div class="flex-auto"${_scopeId3}><a${ssrRenderAttr("href", subItem.href)} class="block font-semibold text-base text-gray-200"${_scopeId3}>${ssrInterpolate(subItem.name)} <span class="absolute inset-0"${_scopeId3}></span></a><p class="mt-1 text-gray-400"${_scopeId3}>${ssrInterpolate(subItem.description)}</p></div></div>`);
                            });
                            _push4(`<!--]--></div>`);
                          } else {
                            return [
                              createVNode("div", { class: "p-4" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                  return openBlock(), createBlock("div", {
                                    key: subItem.name,
                                    class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                  }, [
                                    createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                      (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                        class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                        "aria-hidden": "true"
                                      }))
                                    ]),
                                    createVNode("div", { class: "flex-auto" }, [
                                      createVNode("a", {
                                        href: subItem.href,
                                        class: "block font-semibold text-base text-gray-200"
                                      }, [
                                        createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                        createVNode("span", { class: "absolute inset-0" })
                                      ], 8, ["href"]),
                                      createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                    ])
                                  ]);
                                }), 128))
                              ])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode("div", { class: "relative flex" }, [
                          navItem.href ? (openBlock(), createBlock(_component_NuxtLink, {
                            key: 0,
                            href: navItem.href,
                            onClick: ($event) => selectedNav.value = navItem.name,
                            class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["href", "onClick"])) : (openBlock(), createBlock(unref(PopoverButton), {
                            key: 1,
                            class: [
                              isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                              "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                            ]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["class"]))
                        ]),
                        createVNode(Transition, {
                          "enter-active-class": "transition ease-out duration-200",
                          "enter-from-class": "opacity-0 translate-y-1",
                          "enter-to-class": "opacity-100 translate-y-0",
                          "leave-active-class": "transition ease-in duration-150",
                          "leave-from-class": "opacity-100 translate-y-0",
                          "leave-to-class": "opacity-0 translate-y-1"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "p-4" }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                    return openBlock(), createBlock("div", {
                                      key: subItem.name,
                                      class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                    }, [
                                      createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                        (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                          class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                          "aria-hidden": "true"
                                        }))
                                      ]),
                                      createVNode("div", { class: "flex-auto" }, [
                                        createVNode("a", {
                                          href: subItem.href,
                                          class: "block font-semibold text-base text-gray-200"
                                        }, [
                                          createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                          createVNode("span", { class: "absolute inset-0" })
                                        ], 8, ["href"]),
                                        createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                      ])
                                    ]);
                                  }), 128))
                                ])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            } else {
              return [
                createVNode("div", { class: "flex h-full space-x-8" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(navigation), (navItem) => {
                    return openBlock(), createBlock(unref(Popover), {
                      key: navItem.name,
                      class: "flex relative"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "relative flex" }, [
                          navItem.href ? (openBlock(), createBlock(_component_NuxtLink, {
                            key: 0,
                            href: navItem.href,
                            onClick: ($event) => selectedNav.value = navItem.name,
                            class: "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg font-medium duration-200 ease-out"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["href", "onClick"])) : (openBlock(), createBlock(unref(PopoverButton), {
                            key: 1,
                            class: [
                              isOpen.value ? "border-gray-200 text-gray-200" : "border-transparent text-gray-300 hover:text-gray-400",
                              "group/navItem text-gray-300 overflow-hidden hover:text-gray-400 border-0 relative tracking-wider z-10 -mb-px flex justify-center items-center pt-px text-lg focus-visible:outline-0 font-medium duration-200 ease-out"
                            ]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(navItem.name) + " ", 1),
                              createVNode("span", {
                                class: [selectedNav.value === navItem.name ? "w-full" : "", "transition-all ease-in-out h-0.5 w-0 absolute left-0 bottom-0 bg-white group-hover/navItem:w-full"]
                              }, null, 2)
                            ]),
                            _: 2
                          }, 1032, ["class"]))
                        ]),
                        createVNode(Transition, {
                          "enter-active-class": "transition ease-out duration-200",
                          "enter-from-class": "opacity-0 translate-y-1",
                          "enter-to-class": "opacity-100 translate-y-0",
                          "leave-active-class": "transition ease-in duration-150",
                          "leave-from-class": "opacity-100 translate-y-0",
                          "leave-to-class": "opacity-0 translate-y-1"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(PopoverPanel), { class: "absolute -right-8 top-full z-10 mt-3 w-screen max-w-md overflow-hidden rounded-3xl bg-[#181818] shadow-[0_35px_60px_-15px_rgba(255,255,255,0.1)] ring-1 ring-gray-900/5" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "p-4" }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(navItem.subNavigation, (subItem) => {
                                    return openBlock(), createBlock("div", {
                                      key: subItem.name,
                                      class: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-[#202020]"
                                    }, [
                                      createVNode("div", { class: "flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white" }, [
                                        (openBlock(), createBlock(resolveDynamicComponent(subItem.icon), {
                                          class: "h-6 w-6 text-gray-600 group-hover:text-indigo-600",
                                          "aria-hidden": "true"
                                        }))
                                      ]),
                                      createVNode("div", { class: "flex-auto" }, [
                                        createVNode("a", {
                                          href: subItem.href,
                                          class: "block font-semibold text-base text-gray-200"
                                        }, [
                                          createTextVNode(toDisplayString(subItem.name) + " ", 1),
                                          createVNode("span", { class: "absolute inset-0" })
                                        ], 8, ["href"]),
                                        createVNode("p", { class: "mt-1 text-gray-400" }, toDisplayString(subItem.description), 1)
                                      ])
                                    ]);
                                  }), 128))
                                ])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></nav></header><!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Global/Navigation.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      bodyAttrs: {
        class: "font-sans antialiased relative"
      },
      htmlAttrs: {
        class: "h-full bg-[#121212] overflow-x-hidden scroll-smooth"
      }
    });
    const navigation = reactive([
      {
        name: "About",
        href: "#about"
      },
      {
        name: "Roadmap",
        href: "#roadmap"
      },
      {
        name: "Team",
        href: "#team"
      },
      {
        name: "F.a.q",
        href: "#faq"
      },
      {
        name: "Utility",
        subNavigation: [
          {
            name: "Build a Warrior",
            description: "Create a unique digital collectible using the space-themed and futuristic design elements characteristic of the Galacticore series",
            href: "/build-a-warrior",
            icon: PuzzlePieceIcon
          },
          {
            name: "White Paper",
            description: "Learn about the technical details, use cases, and potential benefits of a specific NFT project or platform.",
            href: "/docs",
            icon: DocumentTextIcon
          }
        ]
      }
    ]);
    const callouts = [
      {
        name: "Documentation",
        description: "Ensure the authenticity, transparency, and security of your NFT with proper documentation on the blockchain ledger - trust that your unique digital asset is genuine and valuable, and easily trade it with confidence in the NFT ecosystem.",
        icon: DocumentTextIcon,
        href: "/docs"
      },
      {
        name: "Build a warrior",
        description: "Experience the thrill of unleashing your imagination and becoming an active participant in the dynamic world of blockchain technology and digital art with Cosmic Warrior NFTs \u2013 create your own unique and captivating digital asset today!",
        icon: PuzzlePieceIcon,
        href: "/build-a-warrior"
      }
    ];
    const faqs = reactive([
      {
        id: 1,
        question: "What is Galacticore NFT?",
        answer: "Galacticore NFT is a digital art project that will be available on Shardeum blockchain in Q2 of 2023. The project consists of unique digital assets, or NFTs, that represent ownership of a piece of digital content related to space and science fiction."
      },
      {
        id: 2,
        question: "What is Shardeum blockchain?",
        answer: "Shardeum blockchain is a new blockchain technology that is being developed specifically for NFT projects like Galacticore. It is designed to be fast, secure, and scalable, and will support a wide range of NFT use cases."
      },
      {
        id: 3,
        question: "How can I buy Galacticore NFTs?",
        answer: "To buy Galacticore NFTs, you will need to have a Shardeum wallet set up with Shardeum coins (SDM). Once you have a wallet set up, you can browse the Galacticore marketplace or visit the project's website to purchase an NFT."
      },
      {
        id: 4,
        question: "What kind of NFTs can I expect to see in Galacticore?",
        answer: "Galacticore will feature a variety of unique digital assets, including artwork, music, and videos, that are related to space and science fiction. Each NFT will be unique and will have its own value based on its rarity and popularity."
      },
      {
        id: 5,
        question: "Can I sell my Galacticore NFTs?",
        answer: "Yes, you can sell your Galacticore NFTs on the Shardeum marketplace or through the project's website. The value of your NFT will depend on a variety of factors, including the rarity of your NFT, the popularity of the project, and the current market conditions."
      }
    ]);
    const team = [
      {
        name: "Leaforewer",
        role: "Co-Founder / CEO",
        imageUrl: "/img/ceo2.png",
        bg_image: "https://images.unsplash.com/photo-1515266591878-f93e32bc5937?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2574&q=80"
      },
      {
        name: "Ferrosia",
        role: "Co-Founder / CEO",
        imageUrl: "/img/ceo1.png",
        bg_image: "https://images.unsplash.com/photo-1515266591878-f93e32bc5937?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2574&q=80"
      },
      {
        name: "Flyingcat",
        role: "Artist / Designer",
        imageUrl: "/img/artist.png",
        bg_image: "https://images.unsplash.com/photo-1515266591878-f93e32bc5937?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2574&q=80"
      },
      {
        name: "Dhexphod",
        role: "Market Analyst",
        imageUrl: "img/analyst.png",
        bg_image: "https://images.unsplash.com/photo-1515266591878-f93e32bc5937?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2574&q=80"
      }
    ];
    const cards = reactive([
      { id: 1, title: "Card 1" },
      { id: 2, title: "Card 2" },
      { id: 3, title: "Card 3" },
      { id: 4, title: "Card 4" },
      { id: 5, title: "Card 5" }
    ]);
    const cardContainer = ref(null);
    let currentPosition = 0;
    const slideRight = () => {
      currentPosition += 1;
      if (currentPosition >= cards.length - 1) {
        const addedCards2 = [...cards];
        cards.push(...addedCards2);
      }
      cardContainer.value.style.transform = `translateX(${-currentPosition * 220}px)`;
    };
    const addedCards = [...cards];
    cards.push(...addedCards);
    ref();
    ref(false);
    ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_GlobalShapeShiftG = __nuxt_component_1;
      const _component_GlobalAnimatedText = _sfc_main$3;
      const _component_GlobalFaq = _sfc_main$2;
      _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
        navigation: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1, { navigation: unref(navigation) }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$1, { navigation: unref(navigation) }, null, 8, ["navigation"])
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative isolate px-6 py-20 lg:px-8"${_scopeId}><div class="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true"${_scopeId}><div class="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-sky-500 to-sky-200 opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" style="${ssrRenderStyle({ "clip-path": "polygon(\r\n                74.1% 44.1%,\r\n                100% 61.6%,\r\n                97.5% 26.9%,\r\n                85.5% 0.1%,\r\n                80.7% 2%,\r\n                72.5% 32.5%,\r\n                60.2% 62.4%,\r\n                52.4% 68.1%,\r\n                47.5% 58.3%,\r\n                45.2% 34.5%,\r\n                27.5% 76.7%,\r\n                0.1% 64.9%,\r\n                17.9% 100%,\r\n                27.6% 76.8%,\r\n                76.1% 97.7%,\r\n                74.1% 44.1%\r\n              )" })}"${_scopeId}></div></div><div class="mx-auto max-w-2xl py-32 sm:py-48 lg:py-56"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GlobalShapeShiftG, { class: "mx-auto" }, null, _parent2, _scopeId));
            _push2(`<div class="text-center mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GlobalAnimatedText, {
              class: "text-white text-3xl tracking-widest font-bold font-[Sen_,sans-serif]",
              text: "WELCOME TO GALACTICORE"
            }, null, _parent2, _scopeId));
            _push2(`<h1 class="text-4xl font-bold font-[Sen_,sans-serif] sm:!leading-normal tracking-normal text-gray-200 sm:text-6xl"${_scopeId}> Explore The Cosmos </h1><div class="hidden sm:mb-2 sm:flex sm:justify-center"${_scopeId}><div class="relative rounded-full px-3 py-1 text-sm leading-6 text-gray-200 hover:ring-gray-900/20"${_scopeId}> Announcing our next steps here. <a href="#" class="font-semibold text-[#9fe870]"${_scopeId}><span class="absolute inset-0" aria-hidden="true"${_scopeId}></span>read more <span aria-hidden="true"${_scopeId}>\u2192</span></a></div></div><p class="mt-6 text-lg leading-8 text-gray-400"${_scopeId}> Galacticore NFT is a collection of unique, hand-crafted digital assets inspired by the vast expanse of the universe. Each NFT is a one-of-a-kind collectible that offers a glimpse into the mysteries of the cosmos. </p></div></div><div class="absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]" aria-hidden="true"${_scopeId}><div class="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-sky-400 to-[#9089fc] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]" style="${ssrRenderStyle({ "clip-path": "polygon(\r\n                74.1% 44.1%,\r\n                100% 61.6%,\r\n                97.5% 26.9%,\r\n                85.5% 0.1%,\r\n                80.7% 2%,\r\n                72.5% 32.5%,\r\n                60.2% 62.4%,\r\n                52.4% 68.1%,\r\n                47.5% 58.3%,\r\n                45.2% 34.5%,\r\n                27.5% 76.7%,\r\n                0.1% 64.9%,\r\n                17.9% 100%,\r\n                27.6% 76.8%,\r\n                76.1% 97.7%,\r\n                74.1% 44.1%\r\n              )" })}"${_scopeId}></div></div></div><div class="relative isolate overflow-hidden px-6 py-24 sm:py-64 lg:overflow-visible lg:px-0"${_scopeId}><div class="absolute inset-0 -z-10 overflow-hidden"${_scopeId}><svg class="absolute left-[max(50%,25rem)] top-0 h-[64rem] w-[128rem] -translate-x-1/2 stroke-[#323232] [mask-image:radial-gradient(64rem_64rem_at_top,transparent,white,transparent)]" aria-hidden="true"${_scopeId}><defs${_scopeId}><pattern id="e813992c-7d03-4cc4-a2bd-151760b470a0" width="200" height="200" x="50%" y="-1" patternUnits="userSpaceOnUse"${_scopeId}><path d="M100 200V.5M.5 .5H200" fill="none"${_scopeId}></path></pattern></defs><svg x="50%" y="-1" class="overflow-visible fill-transparent"${_scopeId}><path d="M-100.5 0h201v201h-201Z M699.5 0h201v201h-201Z M499.5 400h201v201h-201Z M-300.5 600h201v201h-201Z" stroke-width="0"${_scopeId}></path></svg><rect width="100%" height="100%" stroke-width="0" fill="url(#e813992c-7d03-4cc4-a2bd-151760b470a0)"${_scopeId}></rect></svg></div><div id="about" class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 lg:mx-0 lg:max-w-none lg:grid-cols-2 lg:items-start lg:gap-y-10"${_scopeId}><div class="lg:col-span-2 lg:col-start-1 lg:row-start-1 lg:mx-auto lg:grid lg:w-full lg:max-w-7xl lg:grid-cols-2 lg:gap-x-8 lg:px-8"${_scopeId}><div class="lg:pr-4"${_scopeId}><div class="lg:max-w-lg"${_scopeId}><h1 class="mt-2 text-3xl font-bold tracking-tight text-gray-300 sm:text-4xl"${_scopeId}> About us </h1><p class="mt-6 text-xl leading-8 text-gray-200 font-[Sen_,sans-serif]"${_scopeId}> Welcome to Galacticore, an upcoming mining-based #PlayAndEarn game that is set to take the blockchain gaming world by storm! Galacticore is a unique project that combines the exciting world of NFTs with an immersive and engaging gaming experience. </p></div></div></div><div class="-ml-12 -mt-12 p-12 lg:sticky lg:top-4 lg:col-start-2 lg:row-span-2 lg:row-start-1 lg:overflow-hidden"${_scopeId}><img class="w-[48rem] max-w-none rounded-xl bg-gray-900 shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem]" src="https://tailwindui.com/img/component-images/dark-project-app-screenshot.png" alt=""${_scopeId}></div><div class="lg:col-span-2 lg:col-start-1 lg:row-start-2 lg:mx-auto lg:grid lg:w-full lg:max-w-7xl lg:grid-cols-2 lg:gap-x-8 lg:px-8"${_scopeId}><div class="lg:pr-4"${_scopeId}><div class="max-w-xl text-base leading-7 text-gray-200 lg:max-w-lg"${_scopeId}><p${_scopeId}> Galacticore NFTs are the first step in our journey towards creating a thriving gaming community. We believe that by rewarding our community with NFTs, we can create a sense of excitement and anticipation around the launch of our game. </p><p class="mt-8"${_scopeId}> Our NFTs are not just digital collectibles, they are also usable assets that can be used in our future games. We have designed these NFTs to be perfect in every way, from their stunning visuals to their ability to be used as avatars for our buyers. Our NFT series is the perfect way for us to build our community before the game&#39;s launch. We want to give our community a chance to experience the excitement of the game before it is even released. We believe that by doing so, we can create a strong and loyal community that will be with us for years to come. </p><h2 class="mt-16 text-2xl font-bold tracking-tight text-gray-300"${_scopeId}> Wen mint \u{1F914} </h2><p class="mt-6"${_scopeId}> Galacticore is set to be released in Q1 2023 on the Shardeum Blockchain, and we cannot wait for our community to experience the game that we have worked so hard on. We are confident that Galacticore will be a game-changer in the blockchain gaming world, and we look forward to sharing it with our community. Join us on our journey towards creating a vibrant and exciting gaming community. Get your hands on one of our Galacticore NFTs today, and be a part of something truly special! </p></div></div></div></div></div><div class="py-24 sm:py-32 relative"${_scopeId}><div class="mx-auto grid max-w-7xl overflow-hidden"${_scopeId}><div class="flex flex-col items-center"${_scopeId}><div class="relative flex w-full overflow-hidden transition-all ease-out snap-x"${_scopeId}><!--[-->`);
            ssrRenderList(unref(cards), (card) => {
              _push2(`<div class="w-[350px] h-[500px] mr-10 bg-red-600 transition-all ease-in-out snap-center"${_scopeId}><div class="flex flex-col items-center justify-center h-full"${_scopeId}><h2 class="text-lg text-white"${_scopeId}>${ssrInterpolate(card.title)}</h2><p class="text-sm text-white"${_scopeId}>${ssrInterpolate(card.description)}</p></div></div>`);
            });
            _push2(`<!--]--></div></div></div><div class="flex justify-center items-center absolute top-0 right-0 h-full w-1/3"${_scopeId}><button class="text-white rounded-full p-7 bg-[#26284079] backdrop-blur-sm hover:bg-[#535783a1] hover:scale-110 transition-all ease-in-out duration-500"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ChevronRightIcon), { class: "h-10 w-10 text-gray-300 group-hover:text-indigo-600" }, null, _parent2, _scopeId));
            _push2(`</button></div></div><div class="py-24 sm:py-32"${_scopeId}><div id="roadmap" class="mx-auto grid max-w-7xl"${_scopeId}><h1 class="sm:text-4xl text-3xl text-gray-300 my-6"${_scopeId}>Roadmap</h1><div class="grid grid-cols-12 grid-rows-12 gap-4 mt-10"${_scopeId}><div class="col-span-3 row-span-2 bg-blue-500 h-full"${_scopeId}></div><div class="col-span-4 row-span-5 bg-green-500 h-full"${_scopeId}></div><div class="col-span-5 row-span-5 bg-yellow-500 h-full"${_scopeId}></div><div class="col-span-3 row-span-6 bg-pink-500 h-full"${_scopeId}></div><div class="col-span-5 row-span-3 bg-red-500 h-full"${_scopeId}></div><div class="col-span-4 row-span-3 bg-purple-500 h-full"${_scopeId}></div></div></div></div><div class="py-24 sm:py-32 relative"${_scopeId}><div id="team" class="mx-auto grid max-w-7xl gap-x-8 gap-y-20 px-6 lg:px-8 xl:grid-cols-3"${_scopeId}><div class="max-w-2xl"${_scopeId}><h2 class="text-3xl tracking-tight text-gray-300 sm:text-4xl"${_scopeId}> Meet our Team </h2><p class="mt-6 text-lg leading-8 text-gray-400"${_scopeId}> Our team is as unique and valuable as an NFT, and just like a rare digital collectible, we&#39;re here to make a lasting impression in the blockchain world! </p></div><ul role="list" class="grid gap-x-8 gap-y-12 sm:grid-cols-2 sm:gap-y-16 xl:col-span-2 lg:pb-20"${_scopeId}><!--[-->`);
            ssrRenderList(team, (person) => {
              _push2(`<li${_scopeId}><div class="screen"${_scopeId}><div class="screen-image" style="${ssrRenderStyle({ backgroundImage: `url(${person.bg_image})` })}"${_scopeId}></div><div class="screen-overlay"${_scopeId}></div><div class="screen-content relative z-[2] flex flex-col flex-1 justify-end items-center p-5"${_scopeId}><img class="h-56 w-56 rounded-full opacity-80"${ssrRenderAttr("src", person.imageUrl)} alt=""${_scopeId}><div class="text-center mt-12"${_scopeId}><h3 class="text-xl tracking-widest font-semibold leading-7 tracking-relaxed text-white"${_scopeId}>${ssrInterpolate(person.name)}</h3><p class="text-sm italic font-bold leading-6 text-white"${_scopeId}>${ssrInterpolate(person.role)}</p></div></div></div></li>`);
            });
            _push2(`<!--]--></ul></div><div class="absolute -bottom-2 left-0 w-full -z-0 overflow-hidden leading-0 rotate-180"${_scopeId}><svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none"${_scopeId}><path d="M1200 120L0 16.48 0 0 1200 0 1200 120z" class="fill-gray-100"${_scopeId}></path></svg></div></div><div class="bg-gray-100"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl py-16 sm:py-24 lg:pb-56 lg:pt-0 lg:max-w-none lg:py-32"${_scopeId}><h2 class="text-2xl font-bold tracking-wide text-gray-900"${_scopeId}> Check Out These Too! </h2><div class="mt-6 space-y-12 lg:grid lg:grid-cols-4 lg:gap-x-6 lg:space-y-0"${_scopeId}><!--[-->`);
            ssrRenderList(callouts, (callout) => {
              _push2(`<div class="group relative col-span-2"${_scopeId}><div class="relative h-32 w-full overflow-hidden rounded-lg bg-white sm:aspect-h-1 sm:aspect-w-2 lg:aspect-h-1 lg:aspect-w-2 group-hover:opacity-75 sm:h-32"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(callout.icon), { class: "h-32 w-full p-16 bg-gray-200 object-cover object-center" }, null), _parent2, _scopeId);
              _push2(`</div><h3 class="mt-6 text-sm text-gray-500"${_scopeId}><a${ssrRenderAttr("href", callout.href)}${_scopeId}><span class="absolute inset-0"${_scopeId}></span> ${ssrInterpolate(callout.name)}</a></h3><p class="text-base font-semibold text-gray-900"${_scopeId}>${ssrInterpolate(callout.description)}</p></div>`);
            });
            _push2(`<!--]--></div></div></div></div><div class="py-24 sm:py-32 relative"${_scopeId}><div class="mx-auto grid max-w-5xl px-6 lg:px-8"${_scopeId}><h2 class="text-3xl text-gray-300 mx-auto mb-16"${_scopeId}> Frequently Asked Questions [FAQ] </h2>`);
            _push2(ssrRenderComponent(_component_GlobalFaq, { items: unref(faqs) }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "relative isolate px-6 py-20 lg:px-8" }, [
                createVNode("div", {
                  class: "absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80",
                  "aria-hidden": "true"
                }, [
                  createVNode("div", {
                    class: "relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-sky-500 to-sky-200 opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]",
                    style: { "clip-path": "polygon(\r\n                74.1% 44.1%,\r\n                100% 61.6%,\r\n                97.5% 26.9%,\r\n                85.5% 0.1%,\r\n                80.7% 2%,\r\n                72.5% 32.5%,\r\n                60.2% 62.4%,\r\n                52.4% 68.1%,\r\n                47.5% 58.3%,\r\n                45.2% 34.5%,\r\n                27.5% 76.7%,\r\n                0.1% 64.9%,\r\n                17.9% 100%,\r\n                27.6% 76.8%,\r\n                76.1% 97.7%,\r\n                74.1% 44.1%\r\n              )" }
                  })
                ]),
                createVNode("div", { class: "mx-auto max-w-2xl py-32 sm:py-48 lg:py-56" }, [
                  createVNode(_component_GlobalShapeShiftG, { class: "mx-auto" }),
                  createVNode("div", { class: "text-center mt-4" }, [
                    createVNode(_component_GlobalAnimatedText, {
                      class: "text-white text-3xl tracking-widest font-bold font-[Sen_,sans-serif]",
                      text: "WELCOME TO GALACTICORE"
                    }),
                    createVNode("h1", { class: "text-4xl font-bold font-[Sen_,sans-serif] sm:!leading-normal tracking-normal text-gray-200 sm:text-6xl" }, " Explore The Cosmos "),
                    createVNode("div", { class: "hidden sm:mb-2 sm:flex sm:justify-center" }, [
                      createVNode("div", { class: "relative rounded-full px-3 py-1 text-sm leading-6 text-gray-200 hover:ring-gray-900/20" }, [
                        createTextVNode(" Announcing our next steps here. "),
                        createVNode("a", {
                          href: "#",
                          class: "font-semibold text-[#9fe870]"
                        }, [
                          createVNode("span", {
                            class: "absolute inset-0",
                            "aria-hidden": "true"
                          }),
                          createTextVNode("read more "),
                          createVNode("span", { "aria-hidden": "true" }, "\u2192")
                        ])
                      ])
                    ]),
                    createVNode("p", { class: "mt-6 text-lg leading-8 text-gray-400" }, " Galacticore NFT is a collection of unique, hand-crafted digital assets inspired by the vast expanse of the universe. Each NFT is a one-of-a-kind collectible that offers a glimpse into the mysteries of the cosmos. ")
                  ])
                ]),
                createVNode("div", {
                  class: "absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]",
                  "aria-hidden": "true"
                }, [
                  createVNode("div", {
                    class: "relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-sky-400 to-[#9089fc] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]",
                    style: { "clip-path": "polygon(\r\n                74.1% 44.1%,\r\n                100% 61.6%,\r\n                97.5% 26.9%,\r\n                85.5% 0.1%,\r\n                80.7% 2%,\r\n                72.5% 32.5%,\r\n                60.2% 62.4%,\r\n                52.4% 68.1%,\r\n                47.5% 58.3%,\r\n                45.2% 34.5%,\r\n                27.5% 76.7%,\r\n                0.1% 64.9%,\r\n                17.9% 100%,\r\n                27.6% 76.8%,\r\n                76.1% 97.7%,\r\n                74.1% 44.1%\r\n              )" }
                  })
                ])
              ]),
              createVNode("div", { class: "relative isolate overflow-hidden px-6 py-24 sm:py-64 lg:overflow-visible lg:px-0" }, [
                createVNode("div", { class: "absolute inset-0 -z-10 overflow-hidden" }, [
                  (openBlock(), createBlock("svg", {
                    class: "absolute left-[max(50%,25rem)] top-0 h-[64rem] w-[128rem] -translate-x-1/2 stroke-[#323232] [mask-image:radial-gradient(64rem_64rem_at_top,transparent,white,transparent)]",
                    "aria-hidden": "true"
                  }, [
                    createVNode("defs", null, [
                      createVNode("pattern", {
                        id: "e813992c-7d03-4cc4-a2bd-151760b470a0",
                        width: "200",
                        height: "200",
                        x: "50%",
                        y: "-1",
                        patternUnits: "userSpaceOnUse"
                      }, [
                        createVNode("path", {
                          d: "M100 200V.5M.5 .5H200",
                          fill: "none"
                        })
                      ])
                    ]),
                    (openBlock(), createBlock("svg", {
                      x: "50%",
                      y: "-1",
                      class: "overflow-visible fill-transparent"
                    }, [
                      createVNode("path", {
                        d: "M-100.5 0h201v201h-201Z M699.5 0h201v201h-201Z M499.5 400h201v201h-201Z M-300.5 600h201v201h-201Z",
                        "stroke-width": "0"
                      })
                    ])),
                    createVNode("rect", {
                      width: "100%",
                      height: "100%",
                      "stroke-width": "0",
                      fill: "url(#e813992c-7d03-4cc4-a2bd-151760b470a0)"
                    })
                  ]))
                ]),
                createVNode("div", {
                  id: "about",
                  class: "mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 lg:mx-0 lg:max-w-none lg:grid-cols-2 lg:items-start lg:gap-y-10"
                }, [
                  createVNode("div", { class: "lg:col-span-2 lg:col-start-1 lg:row-start-1 lg:mx-auto lg:grid lg:w-full lg:max-w-7xl lg:grid-cols-2 lg:gap-x-8 lg:px-8" }, [
                    createVNode("div", { class: "lg:pr-4" }, [
                      createVNode("div", { class: "lg:max-w-lg" }, [
                        createVNode("h1", { class: "mt-2 text-3xl font-bold tracking-tight text-gray-300 sm:text-4xl" }, " About us "),
                        createVNode("p", { class: "mt-6 text-xl leading-8 text-gray-200 font-[Sen_,sans-serif]" }, " Welcome to Galacticore, an upcoming mining-based #PlayAndEarn game that is set to take the blockchain gaming world by storm! Galacticore is a unique project that combines the exciting world of NFTs with an immersive and engaging gaming experience. ")
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "-ml-12 -mt-12 p-12 lg:sticky lg:top-4 lg:col-start-2 lg:row-span-2 lg:row-start-1 lg:overflow-hidden" }, [
                    createVNode("img", {
                      class: "w-[48rem] max-w-none rounded-xl bg-gray-900 shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem]",
                      src: "https://tailwindui.com/img/component-images/dark-project-app-screenshot.png",
                      alt: ""
                    })
                  ]),
                  createVNode("div", { class: "lg:col-span-2 lg:col-start-1 lg:row-start-2 lg:mx-auto lg:grid lg:w-full lg:max-w-7xl lg:grid-cols-2 lg:gap-x-8 lg:px-8" }, [
                    createVNode("div", { class: "lg:pr-4" }, [
                      createVNode("div", { class: "max-w-xl text-base leading-7 text-gray-200 lg:max-w-lg" }, [
                        createVNode("p", null, " Galacticore NFTs are the first step in our journey towards creating a thriving gaming community. We believe that by rewarding our community with NFTs, we can create a sense of excitement and anticipation around the launch of our game. "),
                        createVNode("p", { class: "mt-8" }, " Our NFTs are not just digital collectibles, they are also usable assets that can be used in our future games. We have designed these NFTs to be perfect in every way, from their stunning visuals to their ability to be used as avatars for our buyers. Our NFT series is the perfect way for us to build our community before the game's launch. We want to give our community a chance to experience the excitement of the game before it is even released. We believe that by doing so, we can create a strong and loyal community that will be with us for years to come. "),
                        createVNode("h2", { class: "mt-16 text-2xl font-bold tracking-tight text-gray-300" }, " Wen mint \u{1F914} "),
                        createVNode("p", { class: "mt-6" }, " Galacticore is set to be released in Q1 2023 on the Shardeum Blockchain, and we cannot wait for our community to experience the game that we have worked so hard on. We are confident that Galacticore will be a game-changer in the blockchain gaming world, and we look forward to sharing it with our community. Join us on our journey towards creating a vibrant and exciting gaming community. Get your hands on one of our Galacticore NFTs today, and be a part of something truly special! ")
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "py-24 sm:py-32 relative" }, [
                createVNode("div", { class: "mx-auto grid max-w-7xl overflow-hidden" }, [
                  createVNode("div", { class: "flex flex-col items-center" }, [
                    createVNode("div", {
                      ref_key: "cardContainer",
                      ref: cardContainer,
                      class: "relative flex w-full overflow-hidden transition-all ease-out snap-x"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(cards), (card) => {
                        return openBlock(), createBlock("div", {
                          key: card.id,
                          class: "w-[350px] h-[500px] mr-10 bg-red-600 transition-all ease-in-out snap-center"
                        }, [
                          createVNode("div", { class: "flex flex-col items-center justify-center h-full" }, [
                            createVNode("h2", { class: "text-lg text-white" }, toDisplayString(card.title), 1),
                            createVNode("p", { class: "text-sm text-white" }, toDisplayString(card.description), 1)
                          ])
                        ]);
                      }), 128))
                    ], 512)
                  ])
                ]),
                createVNode("div", { class: "flex justify-center items-center absolute top-0 right-0 h-full w-1/3" }, [
                  createVNode("button", {
                    class: "text-white rounded-full p-7 bg-[#26284079] backdrop-blur-sm hover:bg-[#535783a1] hover:scale-110 transition-all ease-in-out duration-500",
                    onClick: slideRight
                  }, [
                    createVNode(unref(ChevronRightIcon), { class: "h-10 w-10 text-gray-300 group-hover:text-indigo-600" })
                  ])
                ])
              ]),
              createVNode("div", { class: "py-24 sm:py-32" }, [
                createVNode("div", {
                  id: "roadmap",
                  class: "mx-auto grid max-w-7xl"
                }, [
                  createVNode("h1", { class: "sm:text-4xl text-3xl text-gray-300 my-6" }, "Roadmap"),
                  createVNode("div", { class: "grid grid-cols-12 grid-rows-12 gap-4 mt-10" }, [
                    createVNode("div", { class: "col-span-3 row-span-2 bg-blue-500 h-full" }),
                    createVNode("div", { class: "col-span-4 row-span-5 bg-green-500 h-full" }),
                    createVNode("div", { class: "col-span-5 row-span-5 bg-yellow-500 h-full" }),
                    createVNode("div", { class: "col-span-3 row-span-6 bg-pink-500 h-full" }),
                    createVNode("div", { class: "col-span-5 row-span-3 bg-red-500 h-full" }),
                    createVNode("div", { class: "col-span-4 row-span-3 bg-purple-500 h-full" })
                  ])
                ])
              ]),
              createVNode("div", { class: "py-24 sm:py-32 relative" }, [
                createVNode("div", {
                  id: "team",
                  class: "mx-auto grid max-w-7xl gap-x-8 gap-y-20 px-6 lg:px-8 xl:grid-cols-3"
                }, [
                  createVNode("div", { class: "max-w-2xl" }, [
                    createVNode("h2", { class: "text-3xl tracking-tight text-gray-300 sm:text-4xl" }, " Meet our Team "),
                    createVNode("p", { class: "mt-6 text-lg leading-8 text-gray-400" }, " Our team is as unique and valuable as an NFT, and just like a rare digital collectible, we're here to make a lasting impression in the blockchain world! ")
                  ]),
                  createVNode("ul", {
                    role: "list",
                    class: "grid gap-x-8 gap-y-12 sm:grid-cols-2 sm:gap-y-16 xl:col-span-2 lg:pb-20"
                  }, [
                    (openBlock(), createBlock(Fragment, null, renderList(team, (person) => {
                      return createVNode("li", {
                        key: person.name
                      }, [
                        createVNode("div", { class: "screen" }, [
                          createVNode("div", {
                            class: "screen-image",
                            style: { backgroundImage: `url(${person.bg_image})` }
                          }, null, 4),
                          createVNode("div", { class: "screen-overlay" }),
                          createVNode("div", { class: "screen-content relative z-[2] flex flex-col flex-1 justify-end items-center p-5" }, [
                            createVNode("img", {
                              class: "h-56 w-56 rounded-full opacity-80",
                              src: person.imageUrl,
                              alt: ""
                            }, null, 8, ["src"]),
                            createVNode("div", { class: "text-center mt-12" }, [
                              createVNode("h3", { class: "text-xl tracking-widest font-semibold leading-7 tracking-relaxed text-white" }, toDisplayString(person.name), 1),
                              createVNode("p", { class: "text-sm italic font-bold leading-6 text-white" }, toDisplayString(person.role), 1)
                            ])
                          ])
                        ])
                      ]);
                    }), 64))
                  ])
                ]),
                createVNode("div", { class: "absolute -bottom-2 left-0 w-full -z-0 overflow-hidden leading-0 rotate-180" }, [
                  (openBlock(), createBlock("svg", {
                    "data-name": "Layer 1",
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 1200 120",
                    preserveAspectRatio: "none"
                  }, [
                    createVNode("path", {
                      d: "M1200 120L0 16.48 0 0 1200 0 1200 120z",
                      class: "fill-gray-100"
                    })
                  ]))
                ])
              ]),
              createVNode("div", { class: "bg-gray-100" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "mx-auto max-w-2xl py-16 sm:py-24 lg:pb-56 lg:pt-0 lg:max-w-none lg:py-32" }, [
                    createVNode("h2", { class: "text-2xl font-bold tracking-wide text-gray-900" }, " Check Out These Too! "),
                    createVNode("div", { class: "mt-6 space-y-12 lg:grid lg:grid-cols-4 lg:gap-x-6 lg:space-y-0" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(callouts, (callout) => {
                        return createVNode("div", {
                          key: callout.name,
                          class: "group relative col-span-2"
                        }, [
                          createVNode("div", { class: "relative h-32 w-full overflow-hidden rounded-lg bg-white sm:aspect-h-1 sm:aspect-w-2 lg:aspect-h-1 lg:aspect-w-2 group-hover:opacity-75 sm:h-32" }, [
                            (openBlock(), createBlock(resolveDynamicComponent(callout.icon), { class: "h-32 w-full p-16 bg-gray-200 object-cover object-center" }))
                          ]),
                          createVNode("h3", { class: "mt-6 text-sm text-gray-500" }, [
                            createVNode("a", {
                              href: callout.href
                            }, [
                              createVNode("span", { class: "absolute inset-0" }),
                              createTextVNode(" " + toDisplayString(callout.name), 1)
                            ], 8, ["href"])
                          ]),
                          createVNode("p", { class: "text-base font-semibold text-gray-900" }, toDisplayString(callout.description), 1)
                        ]);
                      }), 64))
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "py-24 sm:py-32 relative" }, [
                createVNode("div", { class: "mx-auto grid max-w-5xl px-6 lg:px-8" }, [
                  createVNode("h2", { class: "text-3xl text-gray-300 mx-auto mb-16" }, " Frequently Asked Questions [FAQ] "),
                  createVNode(_component_GlobalFaq, { items: unref(faqs) }, null, 8, ["items"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-3351343c.mjs.map
