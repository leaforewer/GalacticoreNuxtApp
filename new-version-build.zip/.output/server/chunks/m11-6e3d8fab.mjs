import { b as buildAssetsURL } from './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'vue/server-renderer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const m11 = "" + buildAssetsURL("m11.cd56ca70.png");

export { m11 as default };
//# sourceMappingURL=m11-6e3d8fab.mjs.map
