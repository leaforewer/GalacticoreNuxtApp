import { useSSRContext, ref, unref, withCtx, createTextVNode, toDisplayString, createVNode, renderSlot } from 'vue';
import { ssrInterpolate, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel, DialogTitle } from '@headlessui/vue';
import { XMarkIcon } from '@heroicons/vue/24/outline';

const _sfc_main = {
  __name: "SlideOver",
  __ssrInlineRender: true,
  props: {
    content: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const isOpen = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><button class="text-gray-800 rounded-lg p-4 bg-gray-300 hover:bg-gray-400 transition-all ease-in-out w-full"> Select a ${ssrInterpolate(__props.content)}</button>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: isOpen.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: ($event) => isOpen.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="fixed inset-0"${_scopeId2}></div><div class="fixed inset-0 overflow-hidden"${_scopeId2}><div class="absolute inset-0 overflow-hidden"${_scopeId2}><div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transform transition ease-in-out duration-500 sm:duration-700",
                    "enter-from": "translate-x-full",
                    "enter-to": "translate-x-0",
                    leave: "transform transition ease-in-out duration-500 sm:duration-700",
                    "leave-from": "translate-x-0",
                    "leave-to": "translate-x-full"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "pointer-events-auto w-screen max-w-xl" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="flex h-full flex-col overflow-y-scroll bg-gray-100 pb-6 shadow-xl"${_scopeId4}><div class="px-4 sm:px-6 py-8 bg-[#121212] rounded-b-lg"${_scopeId4}><div class="flex items-start justify-between"${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(DialogTitle), { class: "text-xl font-semibold leading-6 text-gray-300" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`Select Your ${ssrInterpolate(__props.content)}`);
                                  } else {
                                    return [
                                      createTextVNode("Select Your " + toDisplayString(__props.content), 1)
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(`<div class="ml-3 flex h-7 items-center"${_scopeId4}><button type="button" class="rounded-md text-gray-300 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2"${_scopeId4}><span class="sr-only"${_scopeId4}>Close panel</span>`);
                              _push5(ssrRenderComponent(unref(XMarkIcon), {
                                class: "h-7 w-7",
                                "aria-hidden": "true"
                              }, null, _parent5, _scopeId4));
                              _push5(`</button></div></div></div><div class="relative mt-6 flex-1 px-4 sm:px-6"${_scopeId4}>`);
                              ssrRenderSlot(_ctx.$slots, "default", {}, null, _push5, _parent5, _scopeId4);
                              _push5(`</div></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-gray-100 pb-6 shadow-xl" }, [
                                  createVNode("div", { class: "px-4 sm:px-6 py-8 bg-[#121212] rounded-b-lg" }, [
                                    createVNode("div", { class: "flex items-start justify-between" }, [
                                      createVNode(unref(DialogTitle), { class: "text-xl font-semibold leading-6 text-gray-300" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Select Your " + toDisplayString(__props.content), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode("div", { class: "ml-3 flex h-7 items-center" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "rounded-md text-gray-300 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2",
                                          onClick: ($event) => isOpen.value = false
                                        }, [
                                          createVNode("span", { class: "sr-only" }, "Close panel"),
                                          createVNode(unref(XMarkIcon), {
                                            class: "h-7 w-7",
                                            "aria-hidden": "true"
                                          })
                                        ], 8, ["onClick"])
                                      ])
                                    ])
                                  ]),
                                  createVNode("div", { class: "relative mt-6 flex-1 px-4 sm:px-6" }, [
                                    renderSlot(_ctx.$slots, "default")
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 3
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "pointer-events-auto w-screen max-w-xl" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-gray-100 pb-6 shadow-xl" }, [
                                createVNode("div", { class: "px-4 sm:px-6 py-8 bg-[#121212] rounded-b-lg" }, [
                                  createVNode("div", { class: "flex items-start justify-between" }, [
                                    createVNode(unref(DialogTitle), { class: "text-xl font-semibold leading-6 text-gray-300" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Select Your " + toDisplayString(__props.content), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode("div", { class: "ml-3 flex h-7 items-center" }, [
                                      createVNode("button", {
                                        type: "button",
                                        class: "rounded-md text-gray-300 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2",
                                        onClick: ($event) => isOpen.value = false
                                      }, [
                                        createVNode("span", { class: "sr-only" }, "Close panel"),
                                        createVNode(unref(XMarkIcon), {
                                          class: "h-7 w-7",
                                          "aria-hidden": "true"
                                        })
                                      ], 8, ["onClick"])
                                    ])
                                  ])
                                ]),
                                createVNode("div", { class: "relative mt-6 flex-1 px-4 sm:px-6" }, [
                                  renderSlot(_ctx.$slots, "default")
                                ])
                              ])
                            ]),
                            _: 3
                          })
                        ];
                      }
                    }),
                    _: 3
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "fixed inset-0" }),
                    createVNode("div", { class: "fixed inset-0 overflow-hidden" }, [
                      createVNode("div", { class: "absolute inset-0 overflow-hidden" }, [
                        createVNode("div", { class: "pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10" }, [
                          createVNode(unref(TransitionChild), {
                            as: "template",
                            enter: "transform transition ease-in-out duration-500 sm:duration-700",
                            "enter-from": "translate-x-full",
                            "enter-to": "translate-x-0",
                            leave: "transform transition ease-in-out duration-500 sm:duration-700",
                            "leave-from": "translate-x-0",
                            "leave-to": "translate-x-full"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(DialogPanel), { class: "pointer-events-auto w-screen max-w-xl" }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-gray-100 pb-6 shadow-xl" }, [
                                    createVNode("div", { class: "px-4 sm:px-6 py-8 bg-[#121212] rounded-b-lg" }, [
                                      createVNode("div", { class: "flex items-start justify-between" }, [
                                        createVNode(unref(DialogTitle), { class: "text-xl font-semibold leading-6 text-gray-300" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Select Your " + toDisplayString(__props.content), 1)
                                          ]),
                                          _: 1
                                        }),
                                        createVNode("div", { class: "ml-3 flex h-7 items-center" }, [
                                          createVNode("button", {
                                            type: "button",
                                            class: "rounded-md text-gray-300 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2",
                                            onClick: ($event) => isOpen.value = false
                                          }, [
                                            createVNode("span", { class: "sr-only" }, "Close panel"),
                                            createVNode(unref(XMarkIcon), {
                                              class: "h-7 w-7",
                                              "aria-hidden": "true"
                                            })
                                          ], 8, ["onClick"])
                                        ])
                                      ])
                                    ]),
                                    createVNode("div", { class: "relative mt-6 flex-1 px-4 sm:px-6" }, [
                                      renderSlot(_ctx.$slots, "default")
                                    ])
                                  ])
                                ]),
                                _: 3
                              })
                            ]),
                            _: 3
                          })
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: ($event) => isOpen.value = false
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "fixed inset-0" }),
                  createVNode("div", { class: "fixed inset-0 overflow-hidden" }, [
                    createVNode("div", { class: "absolute inset-0 overflow-hidden" }, [
                      createVNode("div", { class: "pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "transform transition ease-in-out duration-500 sm:duration-700",
                          "enter-from": "translate-x-full",
                          "enter-to": "translate-x-0",
                          leave: "transform transition ease-in-out duration-500 sm:duration-700",
                          "leave-from": "translate-x-0",
                          "leave-to": "translate-x-full"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), { class: "pointer-events-auto w-screen max-w-xl" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-gray-100 pb-6 shadow-xl" }, [
                                  createVNode("div", { class: "px-4 sm:px-6 py-8 bg-[#121212] rounded-b-lg" }, [
                                    createVNode("div", { class: "flex items-start justify-between" }, [
                                      createVNode(unref(DialogTitle), { class: "text-xl font-semibold leading-6 text-gray-300" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Select Your " + toDisplayString(__props.content), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode("div", { class: "ml-3 flex h-7 items-center" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "rounded-md text-gray-300 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2",
                                          onClick: ($event) => isOpen.value = false
                                        }, [
                                          createVNode("span", { class: "sr-only" }, "Close panel"),
                                          createVNode(unref(XMarkIcon), {
                                            class: "h-7 w-7",
                                            "aria-hidden": "true"
                                          })
                                        ], 8, ["onClick"])
                                      ])
                                    ])
                                  ]),
                                  createVNode("div", { class: "relative mt-6 flex-1 px-4 sm:px-6" }, [
                                    renderSlot(_ctx.$slots, "default")
                                  ])
                                ])
                              ]),
                              _: 3
                            })
                          ]),
                          _: 3
                        })
                      ])
                    ])
                  ])
                ]),
                _: 3
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 3
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/global/SlideOver.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as default };
//# sourceMappingURL=SlideOver-404cc567.mjs.map
