import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { ChevronDownIcon } from '@heroicons/vue/24/outline';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Faq",
  __ssrInlineRender: true,
  props: {
    items: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const selectedId = ref(0);
    const isOpened = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "flex flex-col justify-center items-center w-full" }, _attrs))}><!--[-->`);
      ssrRenderList(__props.items, (item, index) => {
        _push(`<li class="${ssrRenderClass([[
          index === 0 ? "rounded-t-md" : "",
          index > __props.items.length - 2 ? "rounded-b-md" : "",
          isOpened.value && item.id === selectedId.value ? "bg-sky-400 hover:text-white hover:font-normal" : "bg-[#121212]"
        ], "py-5 px-3 w-full border border-gray-500 cursor-pointer text-white hover:text-gray-400 hover:font-bold transition-all ease-in-out"])}"><div class="flex justify-between items-center"><span>${ssrInterpolate(item.question)}</span><div>`);
        _push(ssrRenderComponent(unref(ChevronDownIcon), {
          class: ["h-6 w-6 transition-all", isOpened.value && item.id === selectedId.value ? "rotate-180" : ""]
        }, null, _parent));
        _push(`</div></div><div class="${ssrRenderClass([
          isOpened.value && item.id === selectedId.value ? "max-h-[500px] p-5" : "max-h-0 p-0",
          "overflow-hidden font-semibold transition-all duration-500 ease-in-out text-white"
        ])}">${ssrInterpolate(item.answer)}</div></li>`);
      });
      _push(`<!--]--></ul>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/global/Faq.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Faq-edb15939.mjs.map
