const client_manifest = {
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_index.c0d2732d.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.c0d2732d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_layout.c2fb6243.js": {
    "resourceType": "script",
    "module": true,
    "file": "layout.c2fb6243.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.ab79b4d8.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.ab79b4d8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.1c601d72.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "popover.05ff340b.css"
    ],
    "file": "popover.1c601d72.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_transition.254bfa4a.js"
    ]
  },
  "popover.05ff340b.css": {
    "file": "popover.05ff340b.css",
    "resourceType": "style"
  },
  "_transition.254bfa4a.js": {
    "resourceType": "script",
    "module": true,
    "file": "transition.254bfa4a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "components/global/AnimatedText.vue": {
    "resourceType": "script",
    "module": true,
    "file": "AnimatedText.29056751.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/AnimatedText.vue"
  },
  "components/global/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Faq.68221947.js",
    "imports": [
      "_index.c0d2732d.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/Faq.vue"
  },
  "components/global/Navigation.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Navigation.77008707.js",
    "imports": [
      "_popover.1c601d72.js",
      "_nuxt-link.ab79b4d8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.c0d2732d.js",
      "_transition.254bfa4a.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/Navigation.vue"
  },
  "components/global/ShapeShiftG.css": {
    "resourceType": "style",
    "file": "ShapeShiftG.9a11deb8.css",
    "src": "components/global/ShapeShiftG.css"
  },
  "components/global/ShapeShiftG.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "ShapeShiftG.03c21fbe.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/ShapeShiftG.vue"
  },
  "ShapeShiftG.9a11deb8.css": {
    "file": "ShapeShiftG.9a11deb8.css",
    "resourceType": "style"
  },
  "components/global/SlideOver.vue": {
    "resourceType": "script",
    "module": true,
    "file": "SlideOver.78dfd010.js",
    "imports": [
      "_index.c0d2732d.js",
      "_transition.254bfa4a.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/SlideOver.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.cf839153.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.8bdbaeb8.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.563ae98c.js",
    "imports": [
      "_nuxt-link.ab79b4d8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.8bdbaeb8.css": {
    "file": "error-404.8bdbaeb8.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.b63a96f5.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.aa54cec4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.b63a96f5.css": {
    "file": "error-500.b63a96f5.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.2d499286.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.2d499286.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "virtual:nuxt:C:/wamp64/www/GalacticoreNuxtApp/.nuxt/error-component.mjs"
    ],
    "file": "entry.5d7ce527.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.2d499286.css": {
    "file": "entry.2d499286.css",
    "resourceType": "style"
  },
  "pages/build-a-warrior.vue": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "public/traits/head/h1.png",
      "public/traits/head/h10.png",
      "public/traits/head/h11.png",
      "public/traits/head/h12.png",
      "public/traits/head/h13.png",
      "public/traits/head/h14.png",
      "public/traits/head/h15.png",
      "public/traits/head/h16.png",
      "public/traits/head/h17.png",
      "public/traits/head/h18.png",
      "public/traits/head/h19.png",
      "public/traits/head/h2.png",
      "public/traits/head/h20.png",
      "public/traits/head/h21.png",
      "public/traits/head/h22.png",
      "public/traits/head/h23.png",
      "public/traits/head/h24.png",
      "public/traits/head/h25.png",
      "public/traits/head/h26.png",
      "public/traits/head/h27.png",
      "public/traits/head/h28.png",
      "public/traits/head/h29.png",
      "public/traits/head/h3.png",
      "public/traits/head/h30.png",
      "public/traits/head/h31.png",
      "public/traits/head/h32.png",
      "public/traits/head/h33.png",
      "public/traits/head/h34.png",
      "public/traits/head/h35.png",
      "public/traits/head/h36.png",
      "public/traits/head/h4.png",
      "public/traits/head/h5.png",
      "public/traits/head/h6.png",
      "public/traits/head/h7.png",
      "public/traits/head/h8.png",
      "public/traits/head/h9.png",
      "public/traits/eye/e1.png",
      "public/traits/eye/e10.png",
      "public/traits/eye/e11.png",
      "public/traits/eye/e12.png",
      "public/traits/eye/e13.png",
      "public/traits/eye/e14.png",
      "public/traits/eye/e15.png",
      "public/traits/eye/e18.png",
      "public/traits/eye/e19.png",
      "public/traits/eye/e2.png",
      "public/traits/eye/e20.png",
      "public/traits/eye/e21.png",
      "public/traits/eye/e22.png",
      "public/traits/eye/e23.png",
      "public/traits/eye/e24.png",
      "public/traits/eye/e25.png",
      "public/traits/eye/e26.png",
      "public/traits/eye/e27.png",
      "public/traits/eye/e28.png",
      "public/traits/eye/e29.png",
      "public/traits/eye/e3.png",
      "public/traits/eye/e30.png",
      "public/traits/eye/e31.png",
      "public/traits/eye/e32.png",
      "public/traits/eye/e33.png",
      "public/traits/eye/e34.png",
      "public/traits/eye/e4.png",
      "public/traits/eye/e5.png",
      "public/traits/eye/e6.png",
      "public/traits/eye/e7.png",
      "public/traits/eye/e8.png",
      "public/traits/eye/e9.png",
      "public/traits/mouth/m1.png",
      "public/traits/mouth/m10.png",
      "public/traits/mouth/m11.png",
      "public/traits/mouth/m12.png",
      "public/traits/mouth/m13.png",
      "public/traits/mouth/m14.png",
      "public/traits/mouth/m15.png",
      "public/traits/mouth/m16.png",
      "public/traits/mouth/m17.png",
      "public/traits/mouth/m18.png",
      "public/traits/mouth/m19.png",
      "public/traits/mouth/m2.png",
      "public/traits/mouth/m20.png",
      "public/traits/mouth/m21.png",
      "public/traits/mouth/m22.png",
      "public/traits/mouth/m23.png",
      "public/traits/mouth/m24.png",
      "public/traits/mouth/m25.png",
      "public/traits/mouth/m26.png",
      "public/traits/mouth/m27.png",
      "public/traits/mouth/m28.png",
      "public/traits/mouth/m29.png",
      "public/traits/mouth/m3.png",
      "public/traits/mouth/m4.png",
      "public/traits/mouth/m5.png",
      "public/traits/mouth/m6.png",
      "public/traits/mouth/m7.png",
      "public/traits/mouth/m8.png",
      "public/traits/mouth/m9.png",
      "public/traits/cloth/c1.png",
      "public/traits/cloth/c10.png",
      "public/traits/cloth/c11.png",
      "public/traits/cloth/c12.png",
      "public/traits/cloth/c13.png",
      "public/traits/cloth/c14.png",
      "public/traits/cloth/c15.png",
      "public/traits/cloth/c16.png",
      "public/traits/cloth/c17.png",
      "public/traits/cloth/c18.png",
      "public/traits/cloth/c19.png",
      "public/traits/cloth/c2.png",
      "public/traits/cloth/c20.png",
      "public/traits/cloth/c21.png",
      "public/traits/cloth/c22.png",
      "public/traits/cloth/c23.png",
      "public/traits/cloth/c24.png",
      "public/traits/cloth/c25.png",
      "public/traits/cloth/c26.png",
      "public/traits/cloth/c27.png",
      "public/traits/cloth/c28.png",
      "public/traits/cloth/c29.png",
      "public/traits/cloth/c3.png",
      "public/traits/cloth/c30.png",
      "public/traits/cloth/c31.png",
      "public/traits/cloth/c32.png",
      "public/traits/cloth/c33.png",
      "public/traits/cloth/c34.png",
      "public/traits/cloth/c35.png",
      "public/traits/cloth/c36.png",
      "public/traits/cloth/c37.png",
      "public/traits/cloth/c38.png",
      "public/traits/cloth/c39.png",
      "public/traits/cloth/c4.png",
      "public/traits/cloth/c40.png",
      "public/traits/cloth/c5.png",
      "public/traits/cloth/c6.png",
      "public/traits/cloth/c7.png",
      "public/traits/cloth/c8.png",
      "public/traits/cloth/c9.png",
      "public/traits/skin/s010.png",
      "public/traits/skin/s09.png",
      "public/traits/skin/s1.png",
      "public/traits/skin/s2.png",
      "public/traits/skin/s3.png",
      "public/traits/skin/s4.png",
      "public/traits/skin/s5.png",
      "public/traits/skin/s6.png",
      "public/traits/skin/s7.png",
      "public/traits/skin/s8.png",
      "public/traits/back/b1.png",
      "public/traits/back/b10.png",
      "public/traits/back/b11.png",
      "public/traits/back/b12.png",
      "public/traits/back/b13.png",
      "public/traits/back/b14.png",
      "public/traits/back/b15.png",
      "public/traits/back/b16.png",
      "public/traits/back/b17.png",
      "public/traits/back/b18.png",
      "public/traits/back/b19.png",
      "public/traits/back/b2.png",
      "public/traits/back/b20.png",
      "public/traits/back/b21.png",
      "public/traits/back/b22.png",
      "public/traits/back/b3.png",
      "public/traits/back/b4.png",
      "public/traits/back/b5.png",
      "public/traits/back/b6.png",
      "public/traits/back/b7.png",
      "public/traits/back/b8.png",
      "public/traits/back/b9.png",
      "public/traits/background/b15.png",
      "public/traits/background/b16.png",
      "public/traits/background/b17.png",
      "public/traits/background/b18.png",
      "public/traits/background/b19.png",
      "public/traits/background/b20.png",
      "public/traits/background/b21.png",
      "public/traits/background/b22.png",
      "public/traits/background/b23.png",
      "public/traits/background/b24.png",
      "public/traits/background/b25.png",
      "public/traits/background/b26.png",
      "public/traits/background/b27.png",
      "public/traits/background/b28.png",
      "public/traits/background/b29.png",
      "public/traits/background/b30.png",
      "public/traits/background/b31.png",
      "public/traits/background/b32.png",
      "public/traits/background/bg1.png",
      "public/traits/background/bg10.png",
      "public/traits/background/bg11.png",
      "public/traits/background/bg12.png",
      "public/traits/background/bg13.png",
      "public/traits/background/bg14.png",
      "public/traits/background/bg2.png",
      "public/traits/background/bg3.png",
      "public/traits/background/bg4.png",
      "public/traits/background/bg5.png",
      "public/traits/background/bg6.png",
      "public/traits/background/bg7.png",
      "public/traits/background/bg8.png",
      "public/traits/background/bg9.png"
    ],
    "file": "build-a-warrior.0c3441ef.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "components/global/SlideOver.vue",
      "_layout.c2fb6243.js",
      "_index.c0d2732d.js",
      "_transition.254bfa4a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/build-a-warrior.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.75918a54.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.ae65a769.js",
    "imports": [
      "_popover.1c601d72.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.c0d2732d.js",
      "_layout.c2fb6243.js",
      "_nuxt-link.ab79b4d8.js",
      "_transition.254bfa4a.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.75918a54.css": {
    "file": "index.75918a54.css",
    "resourceType": "style"
  },
  "popover.css": {
    "resourceType": "style",
    "file": "popover.05ff340b.css",
    "src": "popover.css"
  },
  "public/traits/back/b1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b1.a2a05195.png"
    ],
    "file": "b1.a137d64f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b1.png"
  },
  "b1.a2a05195.png": {
    "file": "b1.a2a05195.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b10.e6550a0e.png"
    ],
    "file": "b10.91dfc8dd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b10.png"
  },
  "b10.e6550a0e.png": {
    "file": "b10.e6550a0e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b11.6efd3a47.png"
    ],
    "file": "b11.433b18fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b11.png"
  },
  "b11.6efd3a47.png": {
    "file": "b11.6efd3a47.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b12.855cd94d.png"
    ],
    "file": "b12.52deb8ee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b12.png"
  },
  "b12.855cd94d.png": {
    "file": "b12.855cd94d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b13.6d687f0b.png"
    ],
    "file": "b13.5e10f03d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b13.png"
  },
  "b13.6d687f0b.png": {
    "file": "b13.6d687f0b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b14.91f7a361.png"
    ],
    "file": "b14.53160b57.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b14.png"
  },
  "b14.91f7a361.png": {
    "file": "b14.91f7a361.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b15.c374d0af.png"
    ],
    "file": "b15.7b1ac273.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b15.png"
  },
  "b15.c374d0af.png": {
    "file": "b15.c374d0af.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b16.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b16.0aa65e89.png"
    ],
    "file": "b16.0f4ccc75.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b16.png"
  },
  "b16.0aa65e89.png": {
    "file": "b16.0aa65e89.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b17.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b17.96cb1287.png"
    ],
    "file": "b17.fdc5740e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b17.png"
  },
  "b17.96cb1287.png": {
    "file": "b17.96cb1287.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b18.d3d9da82.png"
    ],
    "file": "b18.0540a4e1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b18.png"
  },
  "b18.d3d9da82.png": {
    "file": "b18.d3d9da82.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b19.01fcf227.png"
    ],
    "file": "b19.f1697247.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b19.png"
  },
  "b19.01fcf227.png": {
    "file": "b19.01fcf227.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b2.4cd5ea95.png"
    ],
    "file": "b2.0c74e3ca.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b2.png"
  },
  "b2.4cd5ea95.png": {
    "file": "b2.4cd5ea95.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b20.bbde2bb1.png"
    ],
    "file": "b20.ae3488ab.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b20.png"
  },
  "b20.bbde2bb1.png": {
    "file": "b20.bbde2bb1.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b21.2bb6987c.png"
    ],
    "file": "b21.9bf79d26.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b21.png"
  },
  "b21.2bb6987c.png": {
    "file": "b21.2bb6987c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b22.2209a5c7.png"
    ],
    "file": "b22.44cfbeaa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b22.png"
  },
  "b22.2209a5c7.png": {
    "file": "b22.2209a5c7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b3.fb266073.png"
    ],
    "file": "b3.f42a2f25.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b3.png"
  },
  "b3.fb266073.png": {
    "file": "b3.fb266073.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b4.2416a34d.png"
    ],
    "file": "b4.dbaf1694.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b4.png"
  },
  "b4.2416a34d.png": {
    "file": "b4.2416a34d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b5.edce27c3.png"
    ],
    "file": "b5.07e66824.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b5.png"
  },
  "b5.edce27c3.png": {
    "file": "b5.edce27c3.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b6.a5da0a74.png"
    ],
    "file": "b6.a8fe666b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b6.png"
  },
  "b6.a5da0a74.png": {
    "file": "b6.a5da0a74.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b7.afa6a9ee.png"
    ],
    "file": "b7.bf5b67fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b7.png"
  },
  "b7.afa6a9ee.png": {
    "file": "b7.afa6a9ee.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b8.aa3ae242.png"
    ],
    "file": "b8.25aa5e32.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b8.png"
  },
  "b8.aa3ae242.png": {
    "file": "b8.aa3ae242.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/back/b9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b9.8ab43997.png"
    ],
    "file": "b9.1aa957e8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/back/b9.png"
  },
  "b9.8ab43997.png": {
    "file": "b9.8ab43997.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b15.6e21c3f7.png"
    ],
    "file": "b15.923a7dad.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b15.png"
  },
  "b15.6e21c3f7.png": {
    "file": "b15.6e21c3f7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b16.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b16.61fdd276.png"
    ],
    "file": "b16.182bab1c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b16.png"
  },
  "b16.61fdd276.png": {
    "file": "b16.61fdd276.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b17.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b17.55065fd0.png"
    ],
    "file": "b17.6a88908c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b17.png"
  },
  "b17.55065fd0.png": {
    "file": "b17.55065fd0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b18.973864b7.png"
    ],
    "file": "b18.627a582d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b18.png"
  },
  "b18.973864b7.png": {
    "file": "b18.973864b7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b19.9bfc974b.png"
    ],
    "file": "b19.c41598a8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b19.png"
  },
  "b19.9bfc974b.png": {
    "file": "b19.9bfc974b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b20.afc6e840.png"
    ],
    "file": "b20.78c09b4a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b20.png"
  },
  "b20.afc6e840.png": {
    "file": "b20.afc6e840.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b21.fbae385c.png"
    ],
    "file": "b21.a94968d5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b21.png"
  },
  "b21.fbae385c.png": {
    "file": "b21.fbae385c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b22.7d110def.png"
    ],
    "file": "b22.4f4c2303.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b22.png"
  },
  "b22.7d110def.png": {
    "file": "b22.7d110def.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b23.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b23.963c76a3.png"
    ],
    "file": "b23.367e716f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b23.png"
  },
  "b23.963c76a3.png": {
    "file": "b23.963c76a3.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b24.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b24.77f4fea8.png"
    ],
    "file": "b24.ca5bbdc5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b24.png"
  },
  "b24.77f4fea8.png": {
    "file": "b24.77f4fea8.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b25.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b25.728bf436.png"
    ],
    "file": "b25.d9725d4e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b25.png"
  },
  "b25.728bf436.png": {
    "file": "b25.728bf436.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b26.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b26.0a1dd24c.png"
    ],
    "file": "b26.ce2d60c1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b26.png"
  },
  "b26.0a1dd24c.png": {
    "file": "b26.0a1dd24c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b27.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b27.0245e75b.png"
    ],
    "file": "b27.c55958e6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b27.png"
  },
  "b27.0245e75b.png": {
    "file": "b27.0245e75b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b28.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b28.329a6220.png"
    ],
    "file": "b28.a9b1f0e7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b28.png"
  },
  "b28.329a6220.png": {
    "file": "b28.329a6220.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b29.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b29.234c5458.png"
    ],
    "file": "b29.19b9eeb5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b29.png"
  },
  "b29.234c5458.png": {
    "file": "b29.234c5458.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b30.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b30.f3761cb0.png"
    ],
    "file": "b30.841f64ce.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b30.png"
  },
  "b30.f3761cb0.png": {
    "file": "b30.f3761cb0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b31.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b31.9aa8df64.png"
    ],
    "file": "b31.405972fa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b31.png"
  },
  "b31.9aa8df64.png": {
    "file": "b31.9aa8df64.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/b32.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "b32.12adaaa2.png"
    ],
    "file": "b32.ac134be6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/b32.png"
  },
  "b32.12adaaa2.png": {
    "file": "b32.12adaaa2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg1.9b06943f.png"
    ],
    "file": "bg1.fa52b1da.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg1.png"
  },
  "bg1.9b06943f.png": {
    "file": "bg1.9b06943f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg10.7260983a.png"
    ],
    "file": "bg10.1acdc68a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg10.png"
  },
  "bg10.7260983a.png": {
    "file": "bg10.7260983a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg11.9f69d187.png"
    ],
    "file": "bg11.c39001f9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg11.png"
  },
  "bg11.9f69d187.png": {
    "file": "bg11.9f69d187.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg12.429f444e.png"
    ],
    "file": "bg12.56cd07b2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg12.png"
  },
  "bg12.429f444e.png": {
    "file": "bg12.429f444e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg13.d614b128.png"
    ],
    "file": "bg13.54ac52ac.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg13.png"
  },
  "bg13.d614b128.png": {
    "file": "bg13.d614b128.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg14.fc683626.png"
    ],
    "file": "bg14.b9397d4b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg14.png"
  },
  "bg14.fc683626.png": {
    "file": "bg14.fc683626.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg2.5ae7ef87.png"
    ],
    "file": "bg2.078b60a8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg2.png"
  },
  "bg2.5ae7ef87.png": {
    "file": "bg2.5ae7ef87.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg3.ad44c0a1.png"
    ],
    "file": "bg3.3abc0691.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg3.png"
  },
  "bg3.ad44c0a1.png": {
    "file": "bg3.ad44c0a1.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg4.f75ee813.png"
    ],
    "file": "bg4.fedaf5b6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg4.png"
  },
  "bg4.f75ee813.png": {
    "file": "bg4.f75ee813.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg5.550949c6.png"
    ],
    "file": "bg5.8e33682c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg5.png"
  },
  "bg5.550949c6.png": {
    "file": "bg5.550949c6.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg6.5b4ca35b.png"
    ],
    "file": "bg6.39c6e0a7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg6.png"
  },
  "bg6.5b4ca35b.png": {
    "file": "bg6.5b4ca35b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg7.94bac56a.png"
    ],
    "file": "bg7.3dd3aad7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg7.png"
  },
  "bg7.94bac56a.png": {
    "file": "bg7.94bac56a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg8.045a4b67.png"
    ],
    "file": "bg8.9fb69641.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg8.png"
  },
  "bg8.045a4b67.png": {
    "file": "bg8.045a4b67.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/background/bg9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "bg9.7c74af5f.png"
    ],
    "file": "bg9.9a69a799.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/background/bg9.png"
  },
  "bg9.7c74af5f.png": {
    "file": "bg9.7c74af5f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c1.c8f6ac9f.png"
    ],
    "file": "c1.03894bee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c1.png"
  },
  "c1.c8f6ac9f.png": {
    "file": "c1.c8f6ac9f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c10.8f935f57.png"
    ],
    "file": "c10.4eb3e5fd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c10.png"
  },
  "c10.8f935f57.png": {
    "file": "c10.8f935f57.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c11.0f536fdd.png"
    ],
    "file": "c11.01b2b2ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c11.png"
  },
  "c11.0f536fdd.png": {
    "file": "c11.0f536fdd.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c12.26432a65.png"
    ],
    "file": "c12.c1c6e606.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c12.png"
  },
  "c12.26432a65.png": {
    "file": "c12.26432a65.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c13.be9eb503.png"
    ],
    "file": "c13.fc0aa667.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c13.png"
  },
  "c13.be9eb503.png": {
    "file": "c13.be9eb503.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c14.64323bcf.png"
    ],
    "file": "c14.bd1ac929.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c14.png"
  },
  "c14.64323bcf.png": {
    "file": "c14.64323bcf.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c15.a2687d8f.png"
    ],
    "file": "c15.6a8be1bd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c15.png"
  },
  "c15.a2687d8f.png": {
    "file": "c15.a2687d8f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c16.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c16.5d6c840d.png"
    ],
    "file": "c16.9f7c6348.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c16.png"
  },
  "c16.5d6c840d.png": {
    "file": "c16.5d6c840d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c17.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c17.7ce4f79e.png"
    ],
    "file": "c17.d9228819.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c17.png"
  },
  "c17.7ce4f79e.png": {
    "file": "c17.7ce4f79e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c18.e1681215.png"
    ],
    "file": "c18.865279c4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c18.png"
  },
  "c18.e1681215.png": {
    "file": "c18.e1681215.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c19.176d1ef2.png"
    ],
    "file": "c19.c0c0596a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c19.png"
  },
  "c19.176d1ef2.png": {
    "file": "c19.176d1ef2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c2.acb40e7d.png"
    ],
    "file": "c2.19bf0a8b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c2.png"
  },
  "c2.acb40e7d.png": {
    "file": "c2.acb40e7d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c20.50ca30f8.png"
    ],
    "file": "c20.7c87eed4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c20.png"
  },
  "c20.50ca30f8.png": {
    "file": "c20.50ca30f8.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c21.fe293b90.png"
    ],
    "file": "c21.21779381.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c21.png"
  },
  "c21.fe293b90.png": {
    "file": "c21.fe293b90.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c22.6b330e94.png"
    ],
    "file": "c22.6ca5d623.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c22.png"
  },
  "c22.6b330e94.png": {
    "file": "c22.6b330e94.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c23.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c23.6870e8b5.png"
    ],
    "file": "c23.2c157d62.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c23.png"
  },
  "c23.6870e8b5.png": {
    "file": "c23.6870e8b5.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c24.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c24.563fe02f.png"
    ],
    "file": "c24.9c4df8aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c24.png"
  },
  "c24.563fe02f.png": {
    "file": "c24.563fe02f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c25.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c25.2c6eeb1c.png"
    ],
    "file": "c25.ca5d340d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c25.png"
  },
  "c25.2c6eeb1c.png": {
    "file": "c25.2c6eeb1c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c26.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c26.9e5c6d43.png"
    ],
    "file": "c26.6d182e51.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c26.png"
  },
  "c26.9e5c6d43.png": {
    "file": "c26.9e5c6d43.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c27.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c27.5bf52b0e.png"
    ],
    "file": "c27.6cb3f82e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c27.png"
  },
  "c27.5bf52b0e.png": {
    "file": "c27.5bf52b0e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c28.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c28.15562af8.png"
    ],
    "file": "c28.42ca44aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c28.png"
  },
  "c28.15562af8.png": {
    "file": "c28.15562af8.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c29.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c29.641dacd7.png"
    ],
    "file": "c29.ae58706b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c29.png"
  },
  "c29.641dacd7.png": {
    "file": "c29.641dacd7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c3.1e117850.png"
    ],
    "file": "c3.4f6f3749.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c3.png"
  },
  "c3.1e117850.png": {
    "file": "c3.1e117850.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c30.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c30.d90731ce.png"
    ],
    "file": "c30.a337d131.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c30.png"
  },
  "c30.d90731ce.png": {
    "file": "c30.d90731ce.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c31.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c31.3f79a185.png"
    ],
    "file": "c31.cf0b246e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c31.png"
  },
  "c31.3f79a185.png": {
    "file": "c31.3f79a185.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c32.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c32.d9b10136.png"
    ],
    "file": "c32.15719a26.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c32.png"
  },
  "c32.d9b10136.png": {
    "file": "c32.d9b10136.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c33.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c33.3acd695b.png"
    ],
    "file": "c33.b48ef56f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c33.png"
  },
  "c33.3acd695b.png": {
    "file": "c33.3acd695b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c34.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c34.f532216c.png"
    ],
    "file": "c34.83d1a130.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c34.png"
  },
  "c34.f532216c.png": {
    "file": "c34.f532216c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c35.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c35.afd99ecf.png"
    ],
    "file": "c35.2d7a00ae.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c35.png"
  },
  "c35.afd99ecf.png": {
    "file": "c35.afd99ecf.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c36.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c36.759de75d.png"
    ],
    "file": "c36.53fd2a88.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c36.png"
  },
  "c36.759de75d.png": {
    "file": "c36.759de75d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c37.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c37.31ddff0e.png"
    ],
    "file": "c37.d0575d44.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c37.png"
  },
  "c37.31ddff0e.png": {
    "file": "c37.31ddff0e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c38.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c38.ec6c3261.png"
    ],
    "file": "c38.ef69efd8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c38.png"
  },
  "c38.ec6c3261.png": {
    "file": "c38.ec6c3261.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c39.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c39.b9ab1ec6.png"
    ],
    "file": "c39.9f2b7298.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c39.png"
  },
  "c39.b9ab1ec6.png": {
    "file": "c39.b9ab1ec6.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c4.5dc5ac37.png"
    ],
    "file": "c4.491a3061.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c4.png"
  },
  "c4.5dc5ac37.png": {
    "file": "c4.5dc5ac37.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c40.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c40.85e77759.png"
    ],
    "file": "c40.69413eeb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c40.png"
  },
  "c40.85e77759.png": {
    "file": "c40.85e77759.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c5.7040b53e.png"
    ],
    "file": "c5.368e4734.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c5.png"
  },
  "c5.7040b53e.png": {
    "file": "c5.7040b53e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c6.d7b3d4b7.png"
    ],
    "file": "c6.830db3e8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c6.png"
  },
  "c6.d7b3d4b7.png": {
    "file": "c6.d7b3d4b7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c7.941eb194.png"
    ],
    "file": "c7.6e2f7272.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c7.png"
  },
  "c7.941eb194.png": {
    "file": "c7.941eb194.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c8.b78c5364.png"
    ],
    "file": "c8.514e04a7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c8.png"
  },
  "c8.b78c5364.png": {
    "file": "c8.b78c5364.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/cloth/c9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "c9.cc339d47.png"
    ],
    "file": "c9.c69ebc3e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/cloth/c9.png"
  },
  "c9.cc339d47.png": {
    "file": "c9.cc339d47.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e1.b79b0cb0.png"
    ],
    "file": "e1.8494246f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e1.png"
  },
  "e1.b79b0cb0.png": {
    "file": "e1.b79b0cb0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e10.193303d4.png"
    ],
    "file": "e10.fad5abf2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e10.png"
  },
  "e10.193303d4.png": {
    "file": "e10.193303d4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e11.b2c33ddd.png"
    ],
    "file": "e11.5b0e37d9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e11.png"
  },
  "e11.b2c33ddd.png": {
    "file": "e11.b2c33ddd.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e12.5a0a114e.png"
    ],
    "file": "e12.d3956843.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e12.png"
  },
  "e12.5a0a114e.png": {
    "file": "e12.5a0a114e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e13.3d2290f9.png"
    ],
    "file": "e13.0469467d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e13.png"
  },
  "e13.3d2290f9.png": {
    "file": "e13.3d2290f9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e14.b8b9562d.png"
    ],
    "file": "e14.5f7a1a08.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e14.png"
  },
  "e14.b8b9562d.png": {
    "file": "e14.b8b9562d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e15.8ed6b980.png"
    ],
    "file": "e15.1c5cdec6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e15.png"
  },
  "e15.8ed6b980.png": {
    "file": "e15.8ed6b980.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e18.92429753.png"
    ],
    "file": "e18.2171d874.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e18.png"
  },
  "e18.92429753.png": {
    "file": "e18.92429753.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e19.ef43476b.png"
    ],
    "file": "e19.1edabff1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e19.png"
  },
  "e19.ef43476b.png": {
    "file": "e19.ef43476b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e2.bb39f949.png"
    ],
    "file": "e2.7b78529a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e2.png"
  },
  "e2.bb39f949.png": {
    "file": "e2.bb39f949.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e20.9d685601.png"
    ],
    "file": "e20.57903d76.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e20.png"
  },
  "e20.9d685601.png": {
    "file": "e20.9d685601.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e21.f0cb0be2.png"
    ],
    "file": "e21.ef33076f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e21.png"
  },
  "e21.f0cb0be2.png": {
    "file": "e21.f0cb0be2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e22.d0ae1136.png"
    ],
    "file": "e22.7be9afd1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e22.png"
  },
  "e22.d0ae1136.png": {
    "file": "e22.d0ae1136.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e23.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e23.71bc4aa0.png"
    ],
    "file": "e23.d85f1aa9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e23.png"
  },
  "e23.71bc4aa0.png": {
    "file": "e23.71bc4aa0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e24.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e24.c0fc674b.png"
    ],
    "file": "e24.e6bd3e02.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e24.png"
  },
  "e24.c0fc674b.png": {
    "file": "e24.c0fc674b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e25.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e25.a478314c.png"
    ],
    "file": "e25.99150f8b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e25.png"
  },
  "e25.a478314c.png": {
    "file": "e25.a478314c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e26.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e26.c221adc4.png"
    ],
    "file": "e26.0bb70bc3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e26.png"
  },
  "e26.c221adc4.png": {
    "file": "e26.c221adc4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e27.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e27.34856355.png"
    ],
    "file": "e27.9b5b1ac9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e27.png"
  },
  "e27.34856355.png": {
    "file": "e27.34856355.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e28.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e28.bc666bdb.png"
    ],
    "file": "e28.137af382.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e28.png"
  },
  "e28.bc666bdb.png": {
    "file": "e28.bc666bdb.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e29.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e29.4bdc3d30.png"
    ],
    "file": "e29.eaee0c3f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e29.png"
  },
  "e29.4bdc3d30.png": {
    "file": "e29.4bdc3d30.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e3.bbe55e78.png"
    ],
    "file": "e3.0077c463.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e3.png"
  },
  "e3.bbe55e78.png": {
    "file": "e3.bbe55e78.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e30.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e30.0e7b135f.png"
    ],
    "file": "e30.015cfc0a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e30.png"
  },
  "e30.0e7b135f.png": {
    "file": "e30.0e7b135f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e31.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e31.27bf12dc.png"
    ],
    "file": "e31.f7aa7d61.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e31.png"
  },
  "e31.27bf12dc.png": {
    "file": "e31.27bf12dc.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e32.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e32.4ddd531f.png"
    ],
    "file": "e32.a8d67e8b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e32.png"
  },
  "e32.4ddd531f.png": {
    "file": "e32.4ddd531f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e33.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e33.9064cd98.png"
    ],
    "file": "e33.0e2bf455.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e33.png"
  },
  "e33.9064cd98.png": {
    "file": "e33.9064cd98.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e34.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e34.5a0bd2a7.png"
    ],
    "file": "e34.9319f550.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e34.png"
  },
  "e34.5a0bd2a7.png": {
    "file": "e34.5a0bd2a7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e4.084946f0.png"
    ],
    "file": "e4.9621debf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e4.png"
  },
  "e4.084946f0.png": {
    "file": "e4.084946f0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e5.427a8d50.png"
    ],
    "file": "e5.fd468f4d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e5.png"
  },
  "e5.427a8d50.png": {
    "file": "e5.427a8d50.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e6.45d03504.png"
    ],
    "file": "e6.0d32e106.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e6.png"
  },
  "e6.45d03504.png": {
    "file": "e6.45d03504.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e7.a4825ff9.png"
    ],
    "file": "e7.c542c711.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e7.png"
  },
  "e7.a4825ff9.png": {
    "file": "e7.a4825ff9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e8.9da38de2.png"
    ],
    "file": "e8.7b8eb412.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e8.png"
  },
  "e8.9da38de2.png": {
    "file": "e8.9da38de2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/eye/e9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "e9.d07dd9b7.png"
    ],
    "file": "e9.a749b614.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/eye/e9.png"
  },
  "e9.d07dd9b7.png": {
    "file": "e9.d07dd9b7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h1.d5adef40.png"
    ],
    "file": "h1.dfeef708.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h1.png"
  },
  "h1.d5adef40.png": {
    "file": "h1.d5adef40.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h10.6f104a54.png"
    ],
    "file": "h10.dc01786d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h10.png"
  },
  "h10.6f104a54.png": {
    "file": "h10.6f104a54.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h11.fb045a9a.png"
    ],
    "file": "h11.4bb01f24.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h11.png"
  },
  "h11.fb045a9a.png": {
    "file": "h11.fb045a9a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h12.2a65e0e7.png"
    ],
    "file": "h12.e66c487a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h12.png"
  },
  "h12.2a65e0e7.png": {
    "file": "h12.2a65e0e7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h13.9ea0e167.png"
    ],
    "file": "h13.1fc55a45.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h13.png"
  },
  "h13.9ea0e167.png": {
    "file": "h13.9ea0e167.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h14.80289538.png"
    ],
    "file": "h14.7aca0f3a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h14.png"
  },
  "h14.80289538.png": {
    "file": "h14.80289538.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h15.96934e36.png"
    ],
    "file": "h15.9819803d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h15.png"
  },
  "h15.96934e36.png": {
    "file": "h15.96934e36.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h16.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h16.15259f0a.png"
    ],
    "file": "h16.8a1e5278.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h16.png"
  },
  "h16.15259f0a.png": {
    "file": "h16.15259f0a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h17.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h17.7ea07590.png"
    ],
    "file": "h17.618bd5fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h17.png"
  },
  "h17.7ea07590.png": {
    "file": "h17.7ea07590.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h18.45ef58b0.png"
    ],
    "file": "h18.b76d97e9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h18.png"
  },
  "h18.45ef58b0.png": {
    "file": "h18.45ef58b0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h19.d77683a8.png"
    ],
    "file": "h19.68619a40.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h19.png"
  },
  "h19.d77683a8.png": {
    "file": "h19.d77683a8.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h2.cd46bad5.png"
    ],
    "file": "h2.8f16738f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h2.png"
  },
  "h2.cd46bad5.png": {
    "file": "h2.cd46bad5.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h20.b1067a2d.png"
    ],
    "file": "h20.39b11aaf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h20.png"
  },
  "h20.b1067a2d.png": {
    "file": "h20.b1067a2d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h21.65af3823.png"
    ],
    "file": "h21.4600f144.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h21.png"
  },
  "h21.65af3823.png": {
    "file": "h21.65af3823.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h22.62bd240e.png"
    ],
    "file": "h22.c9a36f12.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h22.png"
  },
  "h22.62bd240e.png": {
    "file": "h22.62bd240e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h23.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h23.37050ee4.png"
    ],
    "file": "h23.5812ede8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h23.png"
  },
  "h23.37050ee4.png": {
    "file": "h23.37050ee4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h24.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h24.4c803c37.png"
    ],
    "file": "h24.be8ef03b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h24.png"
  },
  "h24.4c803c37.png": {
    "file": "h24.4c803c37.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h25.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h25.c454a84e.png"
    ],
    "file": "h25.76578ff5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h25.png"
  },
  "h25.c454a84e.png": {
    "file": "h25.c454a84e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h26.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h26.7bf5f132.png"
    ],
    "file": "h26.d47e8858.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h26.png"
  },
  "h26.7bf5f132.png": {
    "file": "h26.7bf5f132.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h27.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h27.3fe5baf6.png"
    ],
    "file": "h27.330095c3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h27.png"
  },
  "h27.3fe5baf6.png": {
    "file": "h27.3fe5baf6.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h28.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h28.1cc70d95.png"
    ],
    "file": "h28.d3ddb8ef.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h28.png"
  },
  "h28.1cc70d95.png": {
    "file": "h28.1cc70d95.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h29.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h29.34d10ad0.png"
    ],
    "file": "h29.c0896313.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h29.png"
  },
  "h29.34d10ad0.png": {
    "file": "h29.34d10ad0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h3.52fc5522.png"
    ],
    "file": "h3.c3ce2838.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h3.png"
  },
  "h3.52fc5522.png": {
    "file": "h3.52fc5522.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h30.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h30.580b8734.png"
    ],
    "file": "h30.9e13afd0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h30.png"
  },
  "h30.580b8734.png": {
    "file": "h30.580b8734.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h31.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h31.b83b5ada.png"
    ],
    "file": "h31.e2487b2c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h31.png"
  },
  "h31.b83b5ada.png": {
    "file": "h31.b83b5ada.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h32.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h32.f2a36fb1.png"
    ],
    "file": "h32.1b4c7065.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h32.png"
  },
  "h32.f2a36fb1.png": {
    "file": "h32.f2a36fb1.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h33.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h33.5087cebf.png"
    ],
    "file": "h33.9d716f97.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h33.png"
  },
  "h33.5087cebf.png": {
    "file": "h33.5087cebf.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h34.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h34.964a8b75.png"
    ],
    "file": "h34.844593f6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h34.png"
  },
  "h34.964a8b75.png": {
    "file": "h34.964a8b75.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h35.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h35.8ccd5320.png"
    ],
    "file": "h35.9f5f9357.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h35.png"
  },
  "h35.8ccd5320.png": {
    "file": "h35.8ccd5320.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h36.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h36.401d7e27.png"
    ],
    "file": "h36.c4f87361.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h36.png"
  },
  "h36.401d7e27.png": {
    "file": "h36.401d7e27.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h4.972416be.png"
    ],
    "file": "h4.c0400cdd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h4.png"
  },
  "h4.972416be.png": {
    "file": "h4.972416be.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h5.96c6f5d9.png"
    ],
    "file": "h5.646cd88c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h5.png"
  },
  "h5.96c6f5d9.png": {
    "file": "h5.96c6f5d9.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h6.51b43801.png"
    ],
    "file": "h6.4a3afc51.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h6.png"
  },
  "h6.51b43801.png": {
    "file": "h6.51b43801.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h7.4a2d3631.png"
    ],
    "file": "h7.c208e56e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h7.png"
  },
  "h7.4a2d3631.png": {
    "file": "h7.4a2d3631.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h8.1e0e97bc.png"
    ],
    "file": "h8.77e1a8f7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h8.png"
  },
  "h8.1e0e97bc.png": {
    "file": "h8.1e0e97bc.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/head/h9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "h9.153a39ba.png"
    ],
    "file": "h9.41820f91.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/head/h9.png"
  },
  "h9.153a39ba.png": {
    "file": "h9.153a39ba.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m1.26eada3c.png"
    ],
    "file": "m1.a5310b5f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m1.png"
  },
  "m1.26eada3c.png": {
    "file": "m1.26eada3c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m10.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m10.eac4c936.png"
    ],
    "file": "m10.189aef81.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m10.png"
  },
  "m10.eac4c936.png": {
    "file": "m10.eac4c936.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m11.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m11.cd56ca70.png"
    ],
    "file": "m11.8f10d587.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m11.png"
  },
  "m11.cd56ca70.png": {
    "file": "m11.cd56ca70.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m12.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m12.efc8df5c.png"
    ],
    "file": "m12.53c4cc75.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m12.png"
  },
  "m12.efc8df5c.png": {
    "file": "m12.efc8df5c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m13.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m13.4304314e.png"
    ],
    "file": "m13.2d6d81c0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m13.png"
  },
  "m13.4304314e.png": {
    "file": "m13.4304314e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m14.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m14.86e64dab.png"
    ],
    "file": "m14.bae1b666.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m14.png"
  },
  "m14.86e64dab.png": {
    "file": "m14.86e64dab.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m15.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m15.e36448a2.png"
    ],
    "file": "m15.06fdd86c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m15.png"
  },
  "m15.e36448a2.png": {
    "file": "m15.e36448a2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m16.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m16.5790fc24.png"
    ],
    "file": "m16.f1ada831.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m16.png"
  },
  "m16.5790fc24.png": {
    "file": "m16.5790fc24.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m17.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m17.ff6f44ee.png"
    ],
    "file": "m17.5b330fb6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m17.png"
  },
  "m17.ff6f44ee.png": {
    "file": "m17.ff6f44ee.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m18.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m18.fc8fefc0.png"
    ],
    "file": "m18.6f6de66b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m18.png"
  },
  "m18.fc8fefc0.png": {
    "file": "m18.fc8fefc0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m19.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m19.ea51fd4d.png"
    ],
    "file": "m19.ec0ab744.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m19.png"
  },
  "m19.ea51fd4d.png": {
    "file": "m19.ea51fd4d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m2.0c9b1731.png"
    ],
    "file": "m2.f460b780.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m2.png"
  },
  "m2.0c9b1731.png": {
    "file": "m2.0c9b1731.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m20.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m20.ad2452a8.png"
    ],
    "file": "m20.5fdff51d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m20.png"
  },
  "m20.ad2452a8.png": {
    "file": "m20.ad2452a8.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m21.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m21.229824ee.png"
    ],
    "file": "m21.cdce2e37.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m21.png"
  },
  "m21.229824ee.png": {
    "file": "m21.229824ee.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m22.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m22.9fba48b5.png"
    ],
    "file": "m22.fe63227b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m22.png"
  },
  "m22.9fba48b5.png": {
    "file": "m22.9fba48b5.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m23.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m23.d8811e1a.png"
    ],
    "file": "m23.66348eff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m23.png"
  },
  "m23.d8811e1a.png": {
    "file": "m23.d8811e1a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m24.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m24.f5b8a1a4.png"
    ],
    "file": "m24.813f0a52.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m24.png"
  },
  "m24.f5b8a1a4.png": {
    "file": "m24.f5b8a1a4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m25.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m25.96eb7cd2.png"
    ],
    "file": "m25.38e8bd68.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m25.png"
  },
  "m25.96eb7cd2.png": {
    "file": "m25.96eb7cd2.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m26.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m26.3eb2cd90.png"
    ],
    "file": "m26.bcc80c4c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m26.png"
  },
  "m26.3eb2cd90.png": {
    "file": "m26.3eb2cd90.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m27.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m27.17c21168.png"
    ],
    "file": "m27.dd106592.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m27.png"
  },
  "m27.17c21168.png": {
    "file": "m27.17c21168.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m28.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m28.a1e33941.png"
    ],
    "file": "m28.934f47d8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m28.png"
  },
  "m28.a1e33941.png": {
    "file": "m28.a1e33941.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m29.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m29.09692976.png"
    ],
    "file": "m29.46c45630.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m29.png"
  },
  "m29.09692976.png": {
    "file": "m29.09692976.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m3.eb34738b.png"
    ],
    "file": "m3.338d3191.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m3.png"
  },
  "m3.eb34738b.png": {
    "file": "m3.eb34738b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m4.3f7cf19a.png"
    ],
    "file": "m4.a99c7a09.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m4.png"
  },
  "m4.3f7cf19a.png": {
    "file": "m4.3f7cf19a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m5.e617a9b7.png"
    ],
    "file": "m5.6249edbe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m5.png"
  },
  "m5.e617a9b7.png": {
    "file": "m5.e617a9b7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m6.db6c898e.png"
    ],
    "file": "m6.5f4ae81c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m6.png"
  },
  "m6.db6c898e.png": {
    "file": "m6.db6c898e.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m7.d9c53287.png"
    ],
    "file": "m7.0a2055e5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m7.png"
  },
  "m7.d9c53287.png": {
    "file": "m7.d9c53287.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m8.23eb3b8c.png"
    ],
    "file": "m8.ac79794d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m8.png"
  },
  "m8.23eb3b8c.png": {
    "file": "m8.23eb3b8c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/mouth/m9.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "m2.0c9b1731.png"
    ],
    "file": "m9.265a7d90.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/mouth/m9.png"
  },
  "public/traits/skin/s010.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s010.0cc27c41.png"
    ],
    "file": "s010.e675336d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s010.png"
  },
  "s010.0cc27c41.png": {
    "file": "s010.0cc27c41.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s09.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s09.64da1e8d.png"
    ],
    "file": "s09.ca96c25b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s09.png"
  },
  "s09.64da1e8d.png": {
    "file": "s09.64da1e8d.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s1.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s1.570a0a3b.png"
    ],
    "file": "s1.7265158d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s1.png"
  },
  "s1.570a0a3b.png": {
    "file": "s1.570a0a3b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s2.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s2.6be921c4.png"
    ],
    "file": "s2.5e00e987.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s2.png"
  },
  "s2.6be921c4.png": {
    "file": "s2.6be921c4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s3.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s3.0a9fff2a.png"
    ],
    "file": "s3.9372ad45.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s3.png"
  },
  "s3.0a9fff2a.png": {
    "file": "s3.0a9fff2a.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s4.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s4.bea8acdd.png"
    ],
    "file": "s4.830bc881.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s4.png"
  },
  "s4.bea8acdd.png": {
    "file": "s4.bea8acdd.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s5.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s5.f6afa8c0.png"
    ],
    "file": "s5.e023c76e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s5.png"
  },
  "s5.f6afa8c0.png": {
    "file": "s5.f6afa8c0.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s6.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s6.1d4a6644.png"
    ],
    "file": "s6.be4922b4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s6.png"
  },
  "s6.1d4a6644.png": {
    "file": "s6.1d4a6644.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s7.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s7.697f0c97.png"
    ],
    "file": "s7.37355ff7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s7.png"
  },
  "s7.697f0c97.png": {
    "file": "s7.697f0c97.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/traits/skin/s8.png": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "s8.87471280.png"
    ],
    "file": "s8.33f8a431.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "public/traits/skin/s8.png"
  },
  "s8.87471280.png": {
    "file": "s8.87471280.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "virtual:nuxt:C:/wamp64/www/GalacticoreNuxtApp/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.9eedc758.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/wamp64/www/GalacticoreNuxtApp/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
