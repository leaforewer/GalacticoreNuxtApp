import { _ as __nuxt_component_0 } from './layout-e31c9add.mjs';
import __nuxt_component_1 from './SlideOver-404cc567.mjs';
import { defineComponent, reactive, ref, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import html2canvas from 'html2canvas';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel, DialogTitle } from '@headlessui/vue';
import { CheckIcon } from '@heroicons/vue/24/outline';
import './server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "build-a-warrior",
  __ssrInlineRender: true,
  setup(__props) {
    let layers = reactive({});
    const headKey = ref(0);
    const eyeKey = ref(0);
    const mouthKey = ref(0);
    const clothKey = ref(0);
    const skinKey = ref(0);
    const backKey = ref(0);
    const backgroundKey = ref(0);
    const successfulMessage = ref(false);
    reactive([]);
    const images = reactive({
      head: {},
      eye: {},
      mouth: {},
      cloth: {},
      skin: {},
      back: {},
      background: {}
    });
    (async () => {
      const headFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/head/h1.png": () => import('./h1-5098ed0d.mjs'), "/public/traits/head/h10.png": () => import('./h10-b9f1b248.mjs'), "/public/traits/head/h11.png": () => import('./h11-32d4d140.mjs'), "/public/traits/head/h12.png": () => import('./h12-f0783987.mjs'), "/public/traits/head/h13.png": () => import('./h13-8814c2c7.mjs'), "/public/traits/head/h14.png": () => import('./h14-b5147b6e.mjs'), "/public/traits/head/h15.png": () => import('./h15-24753739.mjs'), "/public/traits/head/h16.png": () => import('./h16-657d4d15.mjs'), "/public/traits/head/h17.png": () => import('./h17-db9ff219.mjs'), "/public/traits/head/h18.png": () => import('./h18-6685da1f.mjs'), "/public/traits/head/h19.png": () => import('./h19-da042e5d.mjs'), "/public/traits/head/h2.png": () => import('./h2-a1026ccf.mjs'), "/public/traits/head/h20.png": () => import('./h20-f2a012ae.mjs'), "/public/traits/head/h21.png": () => import('./h21-81779ccd.mjs'), "/public/traits/head/h22.png": () => import('./h22-2d384613.mjs'), "/public/traits/head/h23.png": () => import('./h23-5a3accf6.mjs'), "/public/traits/head/h24.png": () => import('./h24-31a4f99e.mjs'), "/public/traits/head/h25.png": () => import('./h25-7b4575b2.mjs'), "/public/traits/head/h26.png": () => import('./h26-8d0abcf1.mjs'), "/public/traits/head/h27.png": () => import('./h27-eddcfd10.mjs'), "/public/traits/head/h28.png": () => import('./h28-38311247.mjs'), "/public/traits/head/h29.png": () => import('./h29-11e3d32a.mjs'), "/public/traits/head/h3.png": () => import('./h3-b7c74882.mjs'), "/public/traits/head/h30.png": () => import('./h30-fee31ea5.mjs'), "/public/traits/head/h31.png": () => import('./h31-48ac8d02.mjs'), "/public/traits/head/h32.png": () => import('./h32-4ea1369e.mjs'), "/public/traits/head/h33.png": () => import('./h33-bc4c53e6.mjs'), "/public/traits/head/h34.png": () => import('./h34-4ab5d742.mjs'), "/public/traits/head/h35.png": () => import('./h35-519b2323.mjs'), "/public/traits/head/h36.png": () => import('./h36-cbb325da.mjs'), "/public/traits/head/h4.png": () => import('./h4-9827118a.mjs'), "/public/traits/head/h5.png": () => import('./h5-3a0415a2.mjs'), "/public/traits/head/h6.png": () => import('./h6-b7b71ef6.mjs'), "/public/traits/head/h7.png": () => import('./h7-015f0d11.mjs'), "/public/traits/head/h8.png": () => import('./h8-1cc9b9dc.mjs'), "/public/traits/head/h9.png": () => import('./h9-e8f5d7bb.mjs') });
      images.head = Object.fromEntries(
        Object.entries(headFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+)\.png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const eyeFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/eye/e1.png": () => import('./e1-7eb0817d.mjs'), "/public/traits/eye/e10.png": () => import('./e10-beacda0a.mjs'), "/public/traits/eye/e11.png": () => import('./e11-165be595.mjs'), "/public/traits/eye/e12.png": () => import('./e12-350f3917.mjs'), "/public/traits/eye/e13.png": () => import('./e13-25ae78ba.mjs'), "/public/traits/eye/e14.png": () => import('./e14-bc156376.mjs'), "/public/traits/eye/e15.png": () => import('./e15-a48f9b99.mjs'), "/public/traits/eye/e18.png": () => import('./e18-a60a0797.mjs'), "/public/traits/eye/e19.png": () => import('./e19-161a2df3.mjs'), "/public/traits/eye/e2.png": () => import('./e2-2319f4b3.mjs'), "/public/traits/eye/e20.png": () => import('./e20-f5161844.mjs'), "/public/traits/eye/e21.png": () => import('./e21-f368aab4.mjs'), "/public/traits/eye/e22.png": () => import('./e22-a736c196.mjs'), "/public/traits/eye/e23.png": () => import('./e23-ded22f18.mjs'), "/public/traits/eye/e24.png": () => import('./e24-c34b3573.mjs'), "/public/traits/eye/e25.png": () => import('./e25-641dd0d6.mjs'), "/public/traits/eye/e26.png": () => import('./e26-cd1e7e5a.mjs'), "/public/traits/eye/e27.png": () => import('./e27-8a772ded.mjs'), "/public/traits/eye/e28.png": () => import('./e28-5e0caa0f.mjs'), "/public/traits/eye/e29.png": () => import('./e29-e831c88d.mjs'), "/public/traits/eye/e3.png": () => import('./e3-e4e4bf99.mjs'), "/public/traits/eye/e30.png": () => import('./e30-2d7357fa.mjs'), "/public/traits/eye/e31.png": () => import('./e31-9f042339.mjs'), "/public/traits/eye/e32.png": () => import('./e32-ec80ddef.mjs'), "/public/traits/eye/e33.png": () => import('./e33-70068e47.mjs'), "/public/traits/eye/e34.png": () => import('./e34-0ee5dab1.mjs'), "/public/traits/eye/e4.png": () => import('./e4-57f6b1d0.mjs'), "/public/traits/eye/e5.png": () => import('./e5-0f7c1d03.mjs'), "/public/traits/eye/e6.png": () => import('./e6-d980c9bd.mjs'), "/public/traits/eye/e7.png": () => import('./e7-f161f732.mjs'), "/public/traits/eye/e8.png": () => import('./e8-7a0a89ac.mjs'), "/public/traits/eye/e9.png": () => import('./e9-d87d1a68.mjs') });
      images.eye = Object.fromEntries(
        Object.entries(eyeFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+)\.png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const mouthFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/mouth/m1.png": () => import('./m1-c624036b.mjs'), "/public/traits/mouth/m10.png": () => import('./m10-e1c41e6d.mjs'), "/public/traits/mouth/m11.png": () => import('./m11-6e3d8fab.mjs'), "/public/traits/mouth/m12.png": () => import('./m12-ba2bcbd1.mjs'), "/public/traits/mouth/m13.png": () => import('./m13-0f5fe6f0.mjs'), "/public/traits/mouth/m14.png": () => import('./m14-611f873e.mjs'), "/public/traits/mouth/m15.png": () => import('./m15-e8fda51c.mjs'), "/public/traits/mouth/m16.png": () => import('./m16-9f40948b.mjs'), "/public/traits/mouth/m17.png": () => import('./m17-dad77bc4.mjs'), "/public/traits/mouth/m18.png": () => import('./m18-f72c7058.mjs'), "/public/traits/mouth/m19.png": () => import('./m19-8536a65e.mjs'), "/public/traits/mouth/m2.png": () => import('./m2-94f02b2a.mjs'), "/public/traits/mouth/m20.png": () => import('./m20-24bb3776.mjs'), "/public/traits/mouth/m21.png": () => import('./m21-fba084f9.mjs'), "/public/traits/mouth/m22.png": () => import('./m22-8cf29587.mjs'), "/public/traits/mouth/m23.png": () => import('./m23-28f10dcf.mjs'), "/public/traits/mouth/m24.png": () => import('./m24-88816a1d.mjs'), "/public/traits/mouth/m25.png": () => import('./m25-03b21fd5.mjs'), "/public/traits/mouth/m26.png": () => import('./m26-5803b93a.mjs'), "/public/traits/mouth/m27.png": () => import('./m27-39777a07.mjs'), "/public/traits/mouth/m28.png": () => import('./m28-591b58db.mjs'), "/public/traits/mouth/m29.png": () => import('./m29-e49d8b5b.mjs'), "/public/traits/mouth/m3.png": () => import('./m3-48fc1db4.mjs'), "/public/traits/mouth/m4.png": () => import('./m4-631e37b0.mjs'), "/public/traits/mouth/m5.png": () => import('./m5-59c7ec7b.mjs'), "/public/traits/mouth/m6.png": () => import('./m6-0eac6b6a.mjs'), "/public/traits/mouth/m7.png": () => import('./m7-d04f0e6e.mjs'), "/public/traits/mouth/m8.png": () => import('./m8-463a86c9.mjs'), "/public/traits/mouth/m9.png": () => import('./m9-eb872c55.mjs') });
      images.mouth = Object.fromEntries(
        Object.entries(mouthFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+)\.png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const clothFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/cloth/c1.png": () => import('./c1-94d19af7.mjs'), "/public/traits/cloth/c10.png": () => import('./c10-d1f34513.mjs'), "/public/traits/cloth/c11.png": () => import('./c11-b104c4fa.mjs'), "/public/traits/cloth/c12.png": () => import('./c12-8db00177.mjs'), "/public/traits/cloth/c13.png": () => import('./c13-b66311a9.mjs'), "/public/traits/cloth/c14.png": () => import('./c14-ec11b386.mjs'), "/public/traits/cloth/c15.png": () => import('./c15-4d7514cc.mjs'), "/public/traits/cloth/c16.png": () => import('./c16-9126d5c3.mjs'), "/public/traits/cloth/c17.png": () => import('./c17-ebefbdce.mjs'), "/public/traits/cloth/c18.png": () => import('./c18-86e9779f.mjs'), "/public/traits/cloth/c19.png": () => import('./c19-9b523df4.mjs'), "/public/traits/cloth/c2.png": () => import('./c2-79be29df.mjs'), "/public/traits/cloth/c20.png": () => import('./c20-846d6ca2.mjs'), "/public/traits/cloth/c21.png": () => import('./c21-33638896.mjs'), "/public/traits/cloth/c22.png": () => import('./c22-1e1ddfd8.mjs'), "/public/traits/cloth/c23.png": () => import('./c23-92283289.mjs'), "/public/traits/cloth/c24.png": () => import('./c24-1196446d.mjs'), "/public/traits/cloth/c25.png": () => import('./c25-cb482061.mjs'), "/public/traits/cloth/c26.png": () => import('./c26-3a96ad48.mjs'), "/public/traits/cloth/c27.png": () => import('./c27-89637bc2.mjs'), "/public/traits/cloth/c28.png": () => import('./c28-30b72d6a.mjs'), "/public/traits/cloth/c29.png": () => import('./c29-c2fbc240.mjs'), "/public/traits/cloth/c3.png": () => import('./c3-189d2675.mjs'), "/public/traits/cloth/c30.png": () => import('./c30-ae9e3412.mjs'), "/public/traits/cloth/c31.png": () => import('./c31-11d79385.mjs'), "/public/traits/cloth/c32.png": () => import('./c32-d0e97c08.mjs'), "/public/traits/cloth/c33.png": () => import('./c33-25583515.mjs'), "/public/traits/cloth/c34.png": () => import('./c34-29f26d75.mjs'), "/public/traits/cloth/c35.png": () => import('./c35-d22cd1ef.mjs'), "/public/traits/cloth/c36.png": () => import('./c36-03b4c4da.mjs'), "/public/traits/cloth/c37.png": () => import('./c37-ebf2a50d.mjs'), "/public/traits/cloth/c38.png": () => import('./c38-26e531f0.mjs'), "/public/traits/cloth/c39.png": () => import('./c39-1efc1413.mjs'), "/public/traits/cloth/c4.png": () => import('./c4-bce26808.mjs'), "/public/traits/cloth/c40.png": () => import('./c40-b643863d.mjs'), "/public/traits/cloth/c5.png": () => import('./c5-0fe8a835.mjs'), "/public/traits/cloth/c6.png": () => import('./c6-f5e4428c.mjs'), "/public/traits/cloth/c7.png": () => import('./c7-5ed480bd.mjs'), "/public/traits/cloth/c8.png": () => import('./c8-84b83ff7.mjs'), "/public/traits/cloth/c9.png": () => import('./c9-3f5d62f6.mjs') });
      images.cloth = Object.fromEntries(
        Object.entries(clothFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+)\.png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const skinFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/skin/s010.png": () => import('./s010-c17c5250.mjs'), "/public/traits/skin/s09.png": () => import('./s09-bedef028.mjs'), "/public/traits/skin/s1.png": () => import('./s1-88cf9052.mjs'), "/public/traits/skin/s2.png": () => import('./s2-44ca6903.mjs'), "/public/traits/skin/s3.png": () => import('./s3-a71cf158.mjs'), "/public/traits/skin/s4.png": () => import('./s4-59965953.mjs'), "/public/traits/skin/s5.png": () => import('./s5-9d1ad913.mjs'), "/public/traits/skin/s6.png": () => import('./s6-820a0c36.mjs'), "/public/traits/skin/s7.png": () => import('./s7-dd35d2ff.mjs'), "/public/traits/skin/s8.png": () => import('./s8-3ecbfb85.mjs') });
      images.skin = Object.fromEntries(
        Object.entries(skinFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+).png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const backFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/back/b1.png": () => import('./b1-7a6d06aa.mjs'), "/public/traits/back/b10.png": () => import('./b10-da8d69cd.mjs'), "/public/traits/back/b11.png": () => import('./b11-b9ff6967.mjs'), "/public/traits/back/b12.png": () => import('./b12-31f75e42.mjs'), "/public/traits/back/b13.png": () => import('./b13-bcd079e6.mjs'), "/public/traits/back/b14.png": () => import('./b14-0a202c27.mjs'), "/public/traits/back/b15.png": () => import('./b15-8d616439.mjs'), "/public/traits/back/b16.png": () => import('./b16-48141993.mjs'), "/public/traits/back/b17.png": () => import('./b17-4df80a4b.mjs'), "/public/traits/back/b18.png": () => import('./b18-abcd85e9.mjs'), "/public/traits/back/b19.png": () => import('./b19-29b85ba0.mjs'), "/public/traits/back/b2.png": () => import('./b2-11374db1.mjs'), "/public/traits/back/b20.png": () => import('./b20-92819d58.mjs'), "/public/traits/back/b21.png": () => import('./b21-b72c1d79.mjs'), "/public/traits/back/b22.png": () => import('./b22-f2364787.mjs'), "/public/traits/back/b3.png": () => import('./b3-3b74e25e.mjs'), "/public/traits/back/b4.png": () => import('./b4-5611e173.mjs'), "/public/traits/back/b5.png": () => import('./b5-3eab23a1.mjs'), "/public/traits/back/b6.png": () => import('./b6-4a7bc116.mjs'), "/public/traits/back/b7.png": () => import('./b7-673d5de4.mjs'), "/public/traits/back/b8.png": () => import('./b8-6951f69c.mjs'), "/public/traits/back/b9.png": () => import('./b9-847f94e2.mjs') });
      images.back = Object.fromEntries(
        Object.entries(backFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+).png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      const bgFiles = await /* @__PURE__ */ Object.assign({ "/public/traits/background/b15.png": () => import('./b15-32c75748.mjs'), "/public/traits/background/b16.png": () => import('./b16-dc0ed3e1.mjs'), "/public/traits/background/b17.png": () => import('./b17-960ea7d1.mjs'), "/public/traits/background/b18.png": () => import('./b18-5441cc84.mjs'), "/public/traits/background/b19.png": () => import('./b19-4325a324.mjs'), "/public/traits/background/b20.png": () => import('./b20-7a12c724.mjs'), "/public/traits/background/b21.png": () => import('./b21-6678af98.mjs'), "/public/traits/background/b22.png": () => import('./b22-79ce98b3.mjs'), "/public/traits/background/b23.png": () => import('./b23-aeee37b5.mjs'), "/public/traits/background/b24.png": () => import('./b24-a11965cc.mjs'), "/public/traits/background/b25.png": () => import('./b25-b7a714d5.mjs'), "/public/traits/background/b26.png": () => import('./b26-ef55b280.mjs'), "/public/traits/background/b27.png": () => import('./b27-70ad6ef8.mjs'), "/public/traits/background/b28.png": () => import('./b28-c0ab0e86.mjs'), "/public/traits/background/b29.png": () => import('./b29-75ffe8fc.mjs'), "/public/traits/background/b30.png": () => import('./b30-19cbf8e6.mjs'), "/public/traits/background/b31.png": () => import('./b31-f70309b0.mjs'), "/public/traits/background/b32.png": () => import('./b32-3e3e0d8f.mjs'), "/public/traits/background/bg1.png": () => import('./bg1-29287e55.mjs'), "/public/traits/background/bg10.png": () => import('./bg10-c24ab631.mjs'), "/public/traits/background/bg11.png": () => import('./bg11-eb309243.mjs'), "/public/traits/background/bg12.png": () => import('./bg12-a81bf8cf.mjs'), "/public/traits/background/bg13.png": () => import('./bg13-e76c2cf0.mjs'), "/public/traits/background/bg14.png": () => import('./bg14-b02f0b15.mjs'), "/public/traits/background/bg2.png": () => import('./bg2-fcd12e87.mjs'), "/public/traits/background/bg3.png": () => import('./bg3-3da746fc.mjs'), "/public/traits/background/bg4.png": () => import('./bg4-bf935940.mjs'), "/public/traits/background/bg5.png": () => import('./bg5-001df674.mjs'), "/public/traits/background/bg6.png": () => import('./bg6-b227bd8a.mjs'), "/public/traits/background/bg7.png": () => import('./bg7-f5bbf0f9.mjs'), "/public/traits/background/bg8.png": () => import('./bg8-d009a590.mjs'), "/public/traits/background/bg9.png": () => import('./bg9-8b9f9f43.mjs') });
      images.background = Object.fromEntries(
        Object.entries(bgFiles).map(([path, image]) => {
          const name = path.match(/\/([^/]+).png$/)[1];
          const absolutePath = image.name.replace("public/", "");
          return [name, absolutePath];
        })
      );
      layers = {
        head: images.head.h1,
        eye: images.eye.e1,
        mouth: images.mouth.m1,
        cloth: images.cloth.c1,
        skin: images.skin.s1,
        back: images.back.b1,
        background: images.background.bg1
      };
    })();
    const handleHead = (head) => {
      layers.head = head;
      headKey.value += 1;
    };
    const handleEye = (eye) => {
      layers.eye = eye;
      eyeKey.value += 1;
    };
    const handleMouth = (mouth) => {
      layers.mouth = mouth;
      mouthKey.value += 1;
    };
    const handleCloth = (cloth) => {
      layers.cloth = cloth;
      clothKey.value += 1;
    };
    const handleSkin = (skin) => {
      layers.skin = skin;
      skinKey.value += 1;
    };
    const handleBack = (back) => {
      layers.back = back;
      backKey.value += 1;
    };
    const handleBackground = (background) => {
      layers.background = background;
      backgroundKey.value += 1;
    };
    function downloadImage() {
      const container = document.querySelector("#layer-container");
      html2canvas(container).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const downloadLink = document.createElement("a");
        downloadLink.setAttribute("download", "your-galactic-warrior.png");
        downloadLink.setAttribute("href", imgData);
        downloadLink.click();
        successfulMessage.value = true;
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_SlideOver = __nuxt_component_1;
      _push(ssrRenderComponent(_component_NuxtLayout, _attrs, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="w-full h-[85vh] flex justify-center items-center"${_scopeId}><div class="flex md:flex-nowrap flex-wrap gap-4 w-full max-w-5xl"${_scopeId}><div class="w-1/2 p-4"${_scopeId}><div id="layer-container" class="max-w-[450px] h-[450px] w-full bg-white relative"${_scopeId}><img class="object-cover absolute inset-0 z-[7]"${ssrRenderAttr("src", unref(layers).head)} alt="selected head trait"${_scopeId}><img class="object-cover absolute inset-0 z-[6]"${ssrRenderAttr("src", unref(layers).eye)} alt="selected eye trait"${_scopeId}><img class="object-cover absolute inset-0 z-[5]"${ssrRenderAttr("src", unref(layers).mouth)} alt="selected mouth trait"${_scopeId}><img class="object-cover absolute inset-0 z-[4]"${ssrRenderAttr("src", unref(layers).cloth)} alt="selected cloth trait"${_scopeId}><img class="object-cover absolute inset-0 z-[3]"${ssrRenderAttr("src", unref(layers).skin)} alt="selected skin trait"${_scopeId}><img class="object-cover absolute inset-0 z-[2]"${ssrRenderAttr("src", unref(layers).back)} alt="selected back trait"${_scopeId}><img class="object-cover absolute inset-0 z-[1]"${ssrRenderAttr("src", unref(layers).background)} alt="selected background trait"${_scopeId}></div></div><div class="flex flex-col justify-center gap-4 items-center w-1/3"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Head" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).head, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).head, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleHead(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Eye" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).eye, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).eye, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleEye(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Mouth" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-2 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).mouth, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer scale-110 flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-2 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).mouth, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleMouth(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer scale-110 flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Cloth" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).cloth, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).cloth, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleCloth(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Skin" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).skin, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).skin, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleSkin(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Back" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).back, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).back, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleBack(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SlideOver, { content: "Background" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-x-6 gap-y-4"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(images).background, (image, key) => {
                    _push3(`<div class="col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"${_scopeId2}><img class="object-cover max-w-full block pb-4"${ssrRenderAttr("alt", key)}${ssrRenderAttr("src", image)}${_scopeId2}></div>`);
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(images).background, (image, key) => {
                        return openBlock(), createBlock("div", {
                          onClick: ($event) => handleBackground(image),
                          class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                        }, [
                          createVNode("img", {
                            class: "object-cover max-w-full block pb-4",
                            alt: key,
                            src: image
                          }, null, 8, ["alt", "src"])
                        ], 8, ["onClick"]);
                      }), 256))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button class="p-6 w-full bg-gray-800 text-white rounded mt-10"${_scopeId}> Download </button></div></div></div>`);
            _push2(ssrRenderComponent(unref(TransitionRoot), {
              as: "template",
              show: unref(successfulMessage)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Dialog), {
                    as: "div",
                    class: "relative z-10",
                    onClose: ($event) => successfulMessage.value = false
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0",
                          "enter-to": "opacity-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100",
                          "leave-to": "opacity-0"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"${_scopeId4}></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`<div class="fixed inset-0 z-10 overflow-y-auto"${_scopeId3}><div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0"${_scopeId3}>`);
                        _push4(ssrRenderComponent(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(DialogPanel), { class: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<div${_scopeId5}><div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100"${_scopeId5}>`);
                                    _push6(ssrRenderComponent(unref(CheckIcon), {
                                      class: "h-6 w-6 text-green-600",
                                      "aria-hidden": "true"
                                    }, null, _parent6, _scopeId5));
                                    _push6(`</div><div class="mt-3 text-center sm:mt-5"${_scopeId5}>`);
                                    _push6(ssrRenderComponent(unref(DialogTitle), {
                                      as: "h3",
                                      class: "text-base font-semibold leading-6 text-gray-900"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Downloaded Successfully `);
                                        } else {
                                          return [
                                            createTextVNode("Downloaded Successfully ")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(`<div class="mt-2"${_scopeId5}><p class="text-sm text-gray-500 leading-8"${_scopeId5}> Don&#39;t forget to share your Warrior with <b class="tracking-wide"${_scopeId5}>#Galacticore on <a target="_blank" href="https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&amp;via=GalacticoreNFT
" class="text-sky-400"${_scopeId5}>Twitter</a></b><br${_scopeId5}>or share it on our <a target="_blank" href="https://discord.gg/AdbmF9pwgZ" class="text-blue-600 font-bold"${_scopeId5}>Discord</a> server! </p></div></div></div><div class="mt-5 sm:mt-6"${_scopeId5}><button type="button" class="inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"${_scopeId5}> Got it! </button></div>`);
                                  } else {
                                    return [
                                      createVNode("div", null, [
                                        createVNode("div", { class: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100" }, [
                                          createVNode(unref(CheckIcon), {
                                            class: "h-6 w-6 text-green-600",
                                            "aria-hidden": "true"
                                          })
                                        ]),
                                        createVNode("div", { class: "mt-3 text-center sm:mt-5" }, [
                                          createVNode(unref(DialogTitle), {
                                            as: "h3",
                                            class: "text-base font-semibold leading-6 text-gray-900"
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Downloaded Successfully ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode("div", { class: "mt-2" }, [
                                            createVNode("p", { class: "text-sm text-gray-500 leading-8" }, [
                                              createTextVNode(" Don't forget to share your Warrior with "),
                                              createVNode("b", { class: "tracking-wide" }, [
                                                createTextVNode("#Galacticore on "),
                                                createVNode("a", {
                                                  target: "_blank",
                                                  href: "https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&via=GalacticoreNFT\r\n",
                                                  class: "text-sky-400"
                                                }, "Twitter")
                                              ]),
                                              createVNode("br"),
                                              createTextVNode("or share it on our "),
                                              createVNode("a", {
                                                target: "_blank",
                                                href: "https://discord.gg/AdbmF9pwgZ",
                                                class: "text-blue-600 font-bold"
                                              }, "Discord"),
                                              createTextVNode(" server! ")
                                            ])
                                          ])
                                        ])
                                      ]),
                                      createVNode("div", { class: "mt-5 sm:mt-6" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                                          onClick: ($event) => successfulMessage.value = false
                                        }, " Got it! ", 8, ["onClick"])
                                      ])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(DialogPanel), { class: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6" }, {
                                  default: withCtx(() => [
                                    createVNode("div", null, [
                                      createVNode("div", { class: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100" }, [
                                        createVNode(unref(CheckIcon), {
                                          class: "h-6 w-6 text-green-600",
                                          "aria-hidden": "true"
                                        })
                                      ]),
                                      createVNode("div", { class: "mt-3 text-center sm:mt-5" }, [
                                        createVNode(unref(DialogTitle), {
                                          as: "h3",
                                          class: "text-base font-semibold leading-6 text-gray-900"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Downloaded Successfully ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode("div", { class: "mt-2" }, [
                                          createVNode("p", { class: "text-sm text-gray-500 leading-8" }, [
                                            createTextVNode(" Don't forget to share your Warrior with "),
                                            createVNode("b", { class: "tracking-wide" }, [
                                              createTextVNode("#Galacticore on "),
                                              createVNode("a", {
                                                target: "_blank",
                                                href: "https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&via=GalacticoreNFT\r\n",
                                                class: "text-sky-400"
                                              }, "Twitter")
                                            ]),
                                            createVNode("br"),
                                            createTextVNode("or share it on our "),
                                            createVNode("a", {
                                              target: "_blank",
                                              href: "https://discord.gg/AdbmF9pwgZ",
                                              class: "text-blue-600 font-bold"
                                            }, "Discord"),
                                            createTextVNode(" server! ")
                                          ])
                                        ])
                                      ])
                                    ]),
                                    createVNode("div", { class: "mt-5 sm:mt-6" }, [
                                      createVNode("button", {
                                        type: "button",
                                        class: "inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                                        onClick: ($event) => successfulMessage.value = false
                                      }, " Got it! ", 8, ["onClick"])
                                    ])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div></div>`);
                      } else {
                        return [
                          createVNode(unref(TransitionChild), {
                            as: "template",
                            enter: "ease-out duration-300",
                            "enter-from": "opacity-0",
                            "enter-to": "opacity-100",
                            leave: "ease-in duration-200",
                            "leave-from": "opacity-100",
                            "leave-to": "opacity-0"
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                            ]),
                            _: 1
                          }),
                          createVNode("div", { class: "fixed inset-0 z-10 overflow-y-auto" }, [
                            createVNode("div", { class: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0" }, [
                              createVNode(unref(TransitionChild), {
                                as: "template",
                                enter: "ease-out duration-300",
                                "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                                "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                                leave: "ease-in duration-200",
                                "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                                "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(DialogPanel), { class: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6" }, {
                                    default: withCtx(() => [
                                      createVNode("div", null, [
                                        createVNode("div", { class: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100" }, [
                                          createVNode(unref(CheckIcon), {
                                            class: "h-6 w-6 text-green-600",
                                            "aria-hidden": "true"
                                          })
                                        ]),
                                        createVNode("div", { class: "mt-3 text-center sm:mt-5" }, [
                                          createVNode(unref(DialogTitle), {
                                            as: "h3",
                                            class: "text-base font-semibold leading-6 text-gray-900"
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Downloaded Successfully ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode("div", { class: "mt-2" }, [
                                            createVNode("p", { class: "text-sm text-gray-500 leading-8" }, [
                                              createTextVNode(" Don't forget to share your Warrior with "),
                                              createVNode("b", { class: "tracking-wide" }, [
                                                createTextVNode("#Galacticore on "),
                                                createVNode("a", {
                                                  target: "_blank",
                                                  href: "https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&via=GalacticoreNFT\r\n",
                                                  class: "text-sky-400"
                                                }, "Twitter")
                                              ]),
                                              createVNode("br"),
                                              createTextVNode("or share it on our "),
                                              createVNode("a", {
                                                target: "_blank",
                                                href: "https://discord.gg/AdbmF9pwgZ",
                                                class: "text-blue-600 font-bold"
                                              }, "Discord"),
                                              createTextVNode(" server! ")
                                            ])
                                          ])
                                        ])
                                      ]),
                                      createVNode("div", { class: "mt-5 sm:mt-6" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                                          onClick: ($event) => successfulMessage.value = false
                                        }, " Got it! ", 8, ["onClick"])
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Dialog), {
                      as: "div",
                      class: "relative z-10",
                      onClose: ($event) => successfulMessage.value = false
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0",
                          "enter-to": "opacity-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100",
                          "leave-to": "opacity-0"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                          ]),
                          _: 1
                        }),
                        createVNode("div", { class: "fixed inset-0 z-10 overflow-y-auto" }, [
                          createVNode("div", { class: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0" }, [
                            createVNode(unref(TransitionChild), {
                              as: "template",
                              enter: "ease-out duration-300",
                              "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                              "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                              leave: "ease-in duration-200",
                              "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                              "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(DialogPanel), { class: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6" }, {
                                  default: withCtx(() => [
                                    createVNode("div", null, [
                                      createVNode("div", { class: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100" }, [
                                        createVNode(unref(CheckIcon), {
                                          class: "h-6 w-6 text-green-600",
                                          "aria-hidden": "true"
                                        })
                                      ]),
                                      createVNode("div", { class: "mt-3 text-center sm:mt-5" }, [
                                        createVNode(unref(DialogTitle), {
                                          as: "h3",
                                          class: "text-base font-semibold leading-6 text-gray-900"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Downloaded Successfully ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode("div", { class: "mt-2" }, [
                                          createVNode("p", { class: "text-sm text-gray-500 leading-8" }, [
                                            createTextVNode(" Don't forget to share your Warrior with "),
                                            createVNode("b", { class: "tracking-wide" }, [
                                              createTextVNode("#Galacticore on "),
                                              createVNode("a", {
                                                target: "_blank",
                                                href: "https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&via=GalacticoreNFT\r\n",
                                                class: "text-sky-400"
                                              }, "Twitter")
                                            ]),
                                            createVNode("br"),
                                            createTextVNode("or share it on our "),
                                            createVNode("a", {
                                              target: "_blank",
                                              href: "https://discord.gg/AdbmF9pwgZ",
                                              class: "text-blue-600 font-bold"
                                            }, "Discord"),
                                            createTextVNode(" server! ")
                                          ])
                                        ])
                                      ])
                                    ]),
                                    createVNode("div", { class: "mt-5 sm:mt-6" }, [
                                      createVNode("button", {
                                        type: "button",
                                        class: "inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                                        onClick: ($event) => successfulMessage.value = false
                                      }, " Got it! ", 8, ["onClick"])
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ]),
                      _: 1
                    }, 8, ["onClose"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "w-full h-[85vh] flex justify-center items-center" }, [
                createVNode("div", { class: "flex md:flex-nowrap flex-wrap gap-4 w-full max-w-5xl" }, [
                  createVNode("div", { class: "w-1/2 p-4" }, [
                    createVNode("div", {
                      id: "layer-container",
                      class: "max-w-[450px] h-[450px] w-full bg-white relative"
                    }, [
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[7]",
                        key: unref(headKey),
                        src: unref(layers).head,
                        alt: "selected head trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[6]",
                        key: unref(eyeKey),
                        src: unref(layers).eye,
                        alt: "selected eye trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[5]",
                        key: unref(mouthKey),
                        src: unref(layers).mouth,
                        alt: "selected mouth trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[4]",
                        key: unref(clothKey),
                        src: unref(layers).cloth,
                        alt: "selected cloth trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[3]",
                        key: unref(skinKey),
                        src: unref(layers).skin,
                        alt: "selected skin trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[2]",
                        key: unref(backKey),
                        src: unref(layers).back,
                        alt: "selected back trait"
                      }, null, 8, ["src"])),
                      (openBlock(), createBlock("img", {
                        class: "object-cover absolute inset-0 z-[1]",
                        key: unref(backgroundKey),
                        src: unref(layers).background,
                        alt: "selected background trait"
                      }, null, 8, ["src"]))
                    ])
                  ]),
                  createVNode("div", { class: "flex flex-col justify-center gap-4 items-center w-1/3" }, [
                    createVNode(_component_SlideOver, { content: "Head" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).head, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleHead(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Eye" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).eye, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleEye(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer h-[100px] flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Mouth" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-2 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).mouth, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleMouth(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer scale-110 flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Cloth" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).cloth, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleCloth(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Skin" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).skin, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleSkin(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Back" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).back, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleBack(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_SlideOver, { content: "Background" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "grid grid-cols-3 gap-x-6 gap-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(images).background, (image, key) => {
                            return openBlock(), createBlock("div", {
                              onClick: ($event) => handleBackground(image),
                              class: "col-span-1 transition-all ease-in-out cursor-pointer flex items-baseline overflow-hidden rounded hover:-translate-y-5 hover:scale-110 hover:bg-gray-300 hover:shadow-xl"
                            }, [
                              createVNode("img", {
                                class: "object-cover max-w-full block pb-4",
                                alt: key,
                                src: image
                              }, null, 8, ["alt", "src"])
                            ], 8, ["onClick"]);
                          }), 256))
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode("button", {
                      onClick: downloadImage,
                      class: "p-6 w-full bg-gray-800 text-white rounded mt-10"
                    }, " Download ")
                  ])
                ])
              ]),
              createVNode(unref(TransitionRoot), {
                as: "template",
                show: unref(successfulMessage)
              }, {
                default: withCtx(() => [
                  createVNode(unref(Dialog), {
                    as: "div",
                    class: "relative z-10",
                    onClose: ($event) => successfulMessage.value = false
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0",
                        "enter-to": "opacity-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100",
                        "leave-to": "opacity-0"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                        ]),
                        _: 1
                      }),
                      createVNode("div", { class: "fixed inset-0 z-10 overflow-y-auto" }, [
                        createVNode("div", { class: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0" }, [
                          createVNode(unref(TransitionChild), {
                            as: "template",
                            enter: "ease-out duration-300",
                            "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                            leave: "ease-in duration-200",
                            "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                            "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(DialogPanel), { class: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6" }, {
                                default: withCtx(() => [
                                  createVNode("div", null, [
                                    createVNode("div", { class: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100" }, [
                                      createVNode(unref(CheckIcon), {
                                        class: "h-6 w-6 text-green-600",
                                        "aria-hidden": "true"
                                      })
                                    ]),
                                    createVNode("div", { class: "mt-3 text-center sm:mt-5" }, [
                                      createVNode(unref(DialogTitle), {
                                        as: "h3",
                                        class: "text-base font-semibold leading-6 text-gray-900"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Downloaded Successfully ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode("div", { class: "mt-2" }, [
                                        createVNode("p", { class: "text-sm text-gray-500 leading-8" }, [
                                          createTextVNode(" Don't forget to share your Warrior with "),
                                          createVNode("b", { class: "tracking-wide" }, [
                                            createTextVNode("#Galacticore on "),
                                            createVNode("a", {
                                              target: "_blank",
                                              href: "https://twitter.com/intent/tweet?text=Check%20out%20my%20awesome%20warrior!&via=GalacticoreNFT\r\n",
                                              class: "text-sky-400"
                                            }, "Twitter")
                                          ]),
                                          createVNode("br"),
                                          createTextVNode("or share it on our "),
                                          createVNode("a", {
                                            target: "_blank",
                                            href: "https://discord.gg/AdbmF9pwgZ",
                                            class: "text-blue-600 font-bold"
                                          }, "Discord"),
                                          createTextVNode(" server! ")
                                        ])
                                      ])
                                    ])
                                  ]),
                                  createVNode("div", { class: "mt-5 sm:mt-6" }, [
                                    createVNode("button", {
                                      type: "button",
                                      class: "inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                                      onClick: ($event) => successfulMessage.value = false
                                    }, " Got it! ", 8, ["onClick"])
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["onClose"])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/build-a-warrior.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=build-a-warrior-e9130166.mjs.map
