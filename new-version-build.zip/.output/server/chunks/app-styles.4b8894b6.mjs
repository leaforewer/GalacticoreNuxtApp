const app_vue_vue_type_style_index_0_lang = "@keyframes rotate{0%{rotate:0deg}50%{scale:1 1.25}to{rotate:1turn}}#blob{animation:rotate 20s infinite;aspect-ratio:1;background:repeating-linear-gradient(90deg,#00dc82 0,#34cdfe 50%,#0047e1);border-radius:50%;filter:blur(13vw);height:28vmax;left:50%;opacity:.8;position:fixed;top:50%;translate:-50% -50%}";

const appStyles_4b8894b6 = [app_vue_vue_type_style_index_0_lang];

export { appStyles_4b8894b6 as default };
//# sourceMappingURL=app-styles.4b8894b6.mjs.map
