import"./entry.5d7ce527.js";const e=""+new URL("b12.855cd94d.png",import.meta.url).href;export{e as default};
