import"./entry.5d7ce527.js";const e=""+new URL("c34.f532216c.png",import.meta.url).href;export{e as default};
