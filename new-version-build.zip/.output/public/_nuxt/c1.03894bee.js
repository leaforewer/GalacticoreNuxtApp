import"./entry.5d7ce527.js";const c=""+new URL("c1.c8f6ac9f.png",import.meta.url).href;export{c as default};
