import"./entry.5d7ce527.js";const t=""+new URL("s09.64da1e8d.png",import.meta.url).href;export{t as default};
