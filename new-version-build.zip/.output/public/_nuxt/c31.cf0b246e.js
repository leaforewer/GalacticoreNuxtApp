import"./entry.5d7ce527.js";const e=""+new URL("c31.3f79a185.png",import.meta.url).href;export{e as default};
