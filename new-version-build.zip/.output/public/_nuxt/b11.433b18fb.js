import"./entry.5d7ce527.js";const t=""+new URL("b11.6efd3a47.png",import.meta.url).href;export{t as default};
