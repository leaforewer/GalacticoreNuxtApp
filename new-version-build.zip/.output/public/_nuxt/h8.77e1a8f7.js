import"./entry.5d7ce527.js";const t=""+new URL("h8.1e0e97bc.png",import.meta.url).href;export{t as default};
