import"./entry.5d7ce527.js";const e=""+new URL("b13.6d687f0b.png",import.meta.url).href;export{e as default};
