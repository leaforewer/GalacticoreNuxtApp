import"./entry.5d7ce527.js";const e=""+new URL("h35.8ccd5320.png",import.meta.url).href;export{e as default};
