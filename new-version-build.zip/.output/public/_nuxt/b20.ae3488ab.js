import"./entry.5d7ce527.js";const e=""+new URL("b20.bbde2bb1.png",import.meta.url).href;export{e as default};
