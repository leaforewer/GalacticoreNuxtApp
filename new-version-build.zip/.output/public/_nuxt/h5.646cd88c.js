import"./entry.5d7ce527.js";const e=""+new URL("h5.96c6f5d9.png",import.meta.url).href;export{e as default};
