import"./entry.5d7ce527.js";const a=""+new URL("s1.570a0a3b.png",import.meta.url).href;export{a as default};
