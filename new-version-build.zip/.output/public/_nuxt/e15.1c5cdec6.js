import"./entry.5d7ce527.js";const t=""+new URL("e15.8ed6b980.png",import.meta.url).href;export{t as default};
