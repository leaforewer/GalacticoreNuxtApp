import"./entry.5d7ce527.js";const e=""+new URL("s6.1d4a6644.png",import.meta.url).href;export{e as default};
