import"./entry.5d7ce527.js";const a=""+new URL("b1.a2a05195.png",import.meta.url).href;export{a as default};
