import"./entry.5d7ce527.js";const t=""+new URL("m8.23eb3b8c.png",import.meta.url).href;export{t as default};
