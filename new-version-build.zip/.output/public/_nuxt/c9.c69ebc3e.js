import"./entry.5d7ce527.js";const c=""+new URL("c9.cc339d47.png",import.meta.url).href;export{c as default};
