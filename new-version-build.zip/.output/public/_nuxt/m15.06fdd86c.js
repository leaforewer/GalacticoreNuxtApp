import"./entry.5d7ce527.js";const t=""+new URL("m15.e36448a2.png",import.meta.url).href;export{t as default};
