import"./entry.5d7ce527.js";const e=""+new URL("b15.c374d0af.png",import.meta.url).href;export{e as default};
