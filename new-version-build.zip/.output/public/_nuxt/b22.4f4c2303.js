import"./entry.5d7ce527.js";const t=""+new URL("b22.7d110def.png",import.meta.url).href;export{t as default};
