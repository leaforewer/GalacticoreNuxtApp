import"./entry.5d7ce527.js";const e=""+new URL("b14.91f7a361.png",import.meta.url).href;export{e as default};
