import"./entry.5d7ce527.js";const t=""+new URL("e13.3d2290f9.png",import.meta.url).href;export{t as default};
