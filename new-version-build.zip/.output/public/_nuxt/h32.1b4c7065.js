import"./entry.5d7ce527.js";const e=""+new URL("h32.f2a36fb1.png",import.meta.url).href;export{e as default};
