import"./entry.5d7ce527.js";const e=""+new URL("c6.d7b3d4b7.png",import.meta.url).href;export{e as default};
