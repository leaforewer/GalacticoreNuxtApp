import"./entry.5d7ce527.js";const t=""+new URL("b16.0aa65e89.png",import.meta.url).href;export{t as default};
