import"./entry.5d7ce527.js";const t=""+new URL("m21.229824ee.png",import.meta.url).href;export{t as default};
