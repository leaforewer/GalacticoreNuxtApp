import"./entry.5d7ce527.js";const e=""+new URL("bg13.d614b128.png",import.meta.url).href;export{e as default};
