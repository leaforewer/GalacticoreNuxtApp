import"./entry.5d7ce527.js";const c=""+new URL("c4.5dc5ac37.png",import.meta.url).href;export{c as default};
