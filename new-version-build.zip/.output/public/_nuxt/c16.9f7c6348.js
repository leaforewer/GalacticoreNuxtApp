import"./entry.5d7ce527.js";const e=""+new URL("c16.5d6c840d.png",import.meta.url).href;export{e as default};
