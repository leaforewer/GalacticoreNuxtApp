import"./entry.5d7ce527.js";const e=""+new URL("c33.3acd695b.png",import.meta.url).href;export{e as default};
