import"./entry.5d7ce527.js";const t=""+new URL("e4.084946f0.png",import.meta.url).href;export{t as default};
