import"./entry.5d7ce527.js";const e=""+new URL("h10.6f104a54.png",import.meta.url).href;export{e as default};
