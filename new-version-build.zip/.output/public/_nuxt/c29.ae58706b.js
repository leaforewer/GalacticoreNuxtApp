import"./entry.5d7ce527.js";const e=""+new URL("c29.641dacd7.png",import.meta.url).href;export{e as default};
