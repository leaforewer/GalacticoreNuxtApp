import"./entry.5d7ce527.js";const t=""+new URL("e34.5a0bd2a7.png",import.meta.url).href;export{t as default};
