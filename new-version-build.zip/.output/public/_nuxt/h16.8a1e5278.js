import"./entry.5d7ce527.js";const e=""+new URL("h16.15259f0a.png",import.meta.url).href;export{e as default};
