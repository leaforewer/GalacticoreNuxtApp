import"./entry.5d7ce527.js";const t=""+new URL("h27.3fe5baf6.png",import.meta.url).href;export{t as default};
