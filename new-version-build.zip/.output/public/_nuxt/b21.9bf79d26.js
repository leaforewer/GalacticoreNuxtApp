import"./entry.5d7ce527.js";const e=""+new URL("b21.2bb6987c.png",import.meta.url).href;export{e as default};
