import"./entry.5d7ce527.js";const e=""+new URL("c12.26432a65.png",import.meta.url).href;export{e as default};
