import"./entry.5d7ce527.js";const t=""+new URL("c7.941eb194.png",import.meta.url).href;export{t as default};
