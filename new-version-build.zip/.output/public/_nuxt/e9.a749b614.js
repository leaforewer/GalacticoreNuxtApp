import"./entry.5d7ce527.js";const t=""+new URL("e9.d07dd9b7.png",import.meta.url).href;export{t as default};
