import"./entry.5d7ce527.js";const e=""+new URL("b17.96cb1287.png",import.meta.url).href;export{e as default};
