import"./entry.5d7ce527.js";const e=""+new URL("bg6.5b4ca35b.png",import.meta.url).href;export{e as default};
