import"./entry.5d7ce527.js";const e=""+new URL("b4.2416a34d.png",import.meta.url).href;export{e as default};
