import"./entry.5d7ce527.js";const t=""+new URL("m26.3eb2cd90.png",import.meta.url).href;export{t as default};
