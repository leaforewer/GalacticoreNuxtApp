import"./entry.5d7ce527.js";const e=""+new URL("bg9.7c74af5f.png",import.meta.url).href;export{e as default};
