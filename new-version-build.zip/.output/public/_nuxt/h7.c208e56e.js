import"./entry.5d7ce527.js";const e=""+new URL("h7.4a2d3631.png",import.meta.url).href;export{e as default};
