import"./entry.5d7ce527.js";const a=""+new URL("h11.fb045a9a.png",import.meta.url).href;export{a as default};
