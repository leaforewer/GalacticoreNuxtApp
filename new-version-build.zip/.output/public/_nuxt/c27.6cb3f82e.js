import"./entry.5d7ce527.js";const t=""+new URL("c27.5bf52b0e.png",import.meta.url).href;export{t as default};
