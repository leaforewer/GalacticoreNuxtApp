import"./entry.5d7ce527.js";const a=""+new URL("b31.9aa8df64.png",import.meta.url).href;export{a as default};
