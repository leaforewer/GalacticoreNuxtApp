import"./entry.5d7ce527.js";const t=""+new URL("e25.a478314c.png",import.meta.url).href;export{t as default};
