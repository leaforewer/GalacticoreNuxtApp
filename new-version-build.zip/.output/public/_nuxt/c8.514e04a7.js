import"./entry.5d7ce527.js";const e=""+new URL("c8.b78c5364.png",import.meta.url).href;export{e as default};
