import"./entry.5d7ce527.js";const a=""+new URL("bg3.ad44c0a1.png",import.meta.url).href;export{a as default};
