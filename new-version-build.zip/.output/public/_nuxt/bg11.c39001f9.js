import"./entry.5d7ce527.js";const e=""+new URL("bg11.9f69d187.png",import.meta.url).href;export{e as default};
