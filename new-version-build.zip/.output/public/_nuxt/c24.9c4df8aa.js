import"./entry.5d7ce527.js";const t=""+new URL("c24.563fe02f.png",import.meta.url).href;export{t as default};
