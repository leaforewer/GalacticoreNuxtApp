import"./entry.5d7ce527.js";const t=""+new URL("s2.6be921c4.png",import.meta.url).href;export{t as default};
