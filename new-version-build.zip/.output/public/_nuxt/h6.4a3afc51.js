import"./entry.5d7ce527.js";const e=""+new URL("h6.51b43801.png",import.meta.url).href;export{e as default};
