import"./entry.5d7ce527.js";const a=""+new URL("b7.afa6a9ee.png",import.meta.url).href;export{a as default};
