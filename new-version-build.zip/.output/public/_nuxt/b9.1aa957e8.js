import"./entry.5d7ce527.js";const e=""+new URL("b9.8ab43997.png",import.meta.url).href;export{e as default};
