import"./entry.5d7ce527.js";const t=""+new URL("bg2.5ae7ef87.png",import.meta.url).href;export{t as default};
