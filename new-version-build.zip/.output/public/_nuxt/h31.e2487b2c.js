import"./entry.5d7ce527.js";const a=""+new URL("h31.b83b5ada.png",import.meta.url).href;export{a as default};
