import"./entry.5d7ce527.js";const e=""+new URL("c28.15562af8.png",import.meta.url).href;export{e as default};
