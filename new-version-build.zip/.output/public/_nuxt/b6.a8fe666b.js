import"./entry.5d7ce527.js";const t=""+new URL("b6.a5da0a74.png",import.meta.url).href;export{t as default};
