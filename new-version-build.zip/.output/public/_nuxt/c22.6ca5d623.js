import"./entry.5d7ce527.js";const t=""+new URL("c22.6b330e94.png",import.meta.url).href;export{t as default};
