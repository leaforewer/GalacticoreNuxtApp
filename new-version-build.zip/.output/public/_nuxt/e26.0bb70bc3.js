import"./entry.5d7ce527.js";const t=""+new URL("e26.c221adc4.png",import.meta.url).href;export{t as default};
