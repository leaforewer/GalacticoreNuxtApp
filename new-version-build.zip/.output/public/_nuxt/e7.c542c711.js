import"./entry.5d7ce527.js";const t=""+new URL("e7.a4825ff9.png",import.meta.url).href;export{t as default};
