import"./entry.5d7ce527.js";const a=""+new URL("m20.ad2452a8.png",import.meta.url).href;export{a as default};
