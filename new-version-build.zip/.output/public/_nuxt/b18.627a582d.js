import"./entry.5d7ce527.js";const e=""+new URL("b18.973864b7.png",import.meta.url).href;export{e as default};
