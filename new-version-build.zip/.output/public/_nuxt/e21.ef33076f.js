import"./entry.5d7ce527.js";const t=""+new URL("e21.f0cb0be2.png",import.meta.url).href;export{t as default};
