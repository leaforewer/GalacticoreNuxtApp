import"./entry.5d7ce527.js";const e=""+new URL("b19.9bfc974b.png",import.meta.url).href;export{e as default};
