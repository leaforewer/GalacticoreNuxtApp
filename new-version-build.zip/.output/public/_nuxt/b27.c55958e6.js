import"./entry.5d7ce527.js";const t=""+new URL("b27.0245e75b.png",import.meta.url).href;export{t as default};
