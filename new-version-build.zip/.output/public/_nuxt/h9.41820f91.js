import"./entry.5d7ce527.js";const a=""+new URL("h9.153a39ba.png",import.meta.url).href;export{a as default};
