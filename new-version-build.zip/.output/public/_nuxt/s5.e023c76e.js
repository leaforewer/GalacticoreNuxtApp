import"./entry.5d7ce527.js";const a=""+new URL("s5.f6afa8c0.png",import.meta.url).href;export{a as default};
