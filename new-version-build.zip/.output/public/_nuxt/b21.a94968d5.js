import"./entry.5d7ce527.js";const t=""+new URL("b21.fbae385c.png",import.meta.url).href;export{t as default};
