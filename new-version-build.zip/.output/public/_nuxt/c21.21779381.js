import"./entry.5d7ce527.js";const t=""+new URL("c21.fe293b90.png",import.meta.url).href;export{t as default};
