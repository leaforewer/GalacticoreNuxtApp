import"./entry.5d7ce527.js";const e=""+new URL("h34.964a8b75.png",import.meta.url).href;export{e as default};
