import"./entry.5d7ce527.js";const t=""+new URL("e31.27bf12dc.png",import.meta.url).href;export{t as default};
