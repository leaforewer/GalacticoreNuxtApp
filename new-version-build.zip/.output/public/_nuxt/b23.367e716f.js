import"./entry.5d7ce527.js";const e=""+new URL("b23.963c76a3.png",import.meta.url).href;export{e as default};
