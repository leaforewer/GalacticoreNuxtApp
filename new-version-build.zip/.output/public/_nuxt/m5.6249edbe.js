import"./entry.5d7ce527.js";const t=""+new URL("m5.e617a9b7.png",import.meta.url).href;export{t as default};
