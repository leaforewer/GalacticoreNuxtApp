import"./entry.5d7ce527.js";const t=""+new URL("e30.0e7b135f.png",import.meta.url).href;export{t as default};
