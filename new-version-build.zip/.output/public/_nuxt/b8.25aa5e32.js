import"./entry.5d7ce527.js";const e=""+new URL("b8.aa3ae242.png",import.meta.url).href;export{e as default};
