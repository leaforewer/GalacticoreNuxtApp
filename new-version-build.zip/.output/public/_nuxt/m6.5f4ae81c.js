import"./entry.5d7ce527.js";const t=""+new URL("m6.db6c898e.png",import.meta.url).href;export{t as default};
