import"./entry.5d7ce527.js";const t=""+new URL("c23.6870e8b5.png",import.meta.url).href;export{t as default};
