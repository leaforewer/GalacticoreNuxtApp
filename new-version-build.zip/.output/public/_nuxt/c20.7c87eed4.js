import"./entry.5d7ce527.js";const e=""+new URL("c20.50ca30f8.png",import.meta.url).href;export{e as default};
