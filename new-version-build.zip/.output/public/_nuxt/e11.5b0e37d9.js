import"./entry.5d7ce527.js";const t=""+new URL("e11.b2c33ddd.png",import.meta.url).href;export{t as default};
