import"./entry.5d7ce527.js";const t=""+new URL("e1.b79b0cb0.png",import.meta.url).href;export{t as default};
